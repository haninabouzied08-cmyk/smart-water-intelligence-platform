// App.js
import React from "react";
import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import ProtectedRoute from "./components/ProtectedRoute";
import ProtectedIrrigationRoute from "./components/ProtectedIrrigationRoute";
// Import components
import Topbar from "./components/Topbar";
import Footer from "./components/Footer";
import Spinner from "./components/Spinner";
import BackToTop from "./components/BackToTop";

// Import pages
import HomePage from "./pages/Home";
import AboutPage from "./pages/About";
import ContactPage from "./pages/Contact";
import LoginSignup from './pages/Login';
import SWIP from "./pages/SWIP";
import ContentList from "./pages/ContentList";
import ContentDetails from "./pages/ContentDetails";
import IrrigationHistory from "./pages/IrrigationHistory";
import TodayIrrigation from "./pages/TodayIrrigation";
import SearchResults from "./pages/SearchResults";
import ProjectDetails from "./pages/ProjectDetails";

import './App.css';
import 'bootstrap/dist/css/bootstrap.min.css';

function App() {
  return (
    <Router>
      <Topbar />
      <Routes>
        <Route path="/" element={<HomePage />} />
        {/* <Route path="/projects" element={<ContentList type="project" />} /> */}
        <Route path="/blogs" element={<ContentList type="blog" />} />
        <Route path="/training" element={<ContentList type="training" />} />
        <Route path="/publications" element={<ContentList type="publication" />} />
        <Route path="/reports" element={<ContentList type="report" />} />
        <Route path="/events" element={<ContentList type="event" />} />
        <Route path="/content/:publicId" element={<ContentDetails />} />
        <Route path="/project/:publicId" element={<ProjectDetails />} />
        <Route path="/about" element={<AboutPage />} />
        <Route path="/contact" element={<ContactPage />} />
        <Route path="/search" element={<SearchResults />} />
        <Route path="/login" element={<LoginSignup />} />
        <Route
          path="/swip"
          element={
            <ProtectedRoute>
              <SWIP />
            </ProtectedRoute>
          }
        />
        <Route
          path="/irrigation"
          element={
            <ProtectedRoute>
              <IrrigationHistory />
            </ProtectedRoute>
          }
        />

        <Route
          path="/today-irrigation"
          element={
            <ProtectedRoute>
              <TodayIrrigation />
            </ProtectedRoute>
          }
        />
        </Routes>
      <BackToTop />
      <Footer />
    </Router>
  );
}

export default App;
