import api from "./api";

/**
 * List contents by type
 */
export const getPublicContents = async (type) => {
  const res = await api.get("/contents", {
    params: { type }
  });
  return res.data;
};

/**
 * Get content by encrypted ID
 */
export const getContentByPublicId = async (publicId) => {
  const res = await api.get(`/contents/public/${publicId}`);
  return res.data;
};
