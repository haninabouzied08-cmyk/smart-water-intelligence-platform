import api from "./api";

export const searchContents = async (keyword) => {
  const res = await api.get("/contents/search", {
    params: { keyword }
  });
  return res.data;
};
