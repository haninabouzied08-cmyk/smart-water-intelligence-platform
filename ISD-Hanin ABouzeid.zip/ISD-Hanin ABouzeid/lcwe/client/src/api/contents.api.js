import api from "./api";

export const getContents = async ({ type, page, search }) => {
  const res = await api.get("/contents", {
    params: {
      type,
      page,
      limit: 10,
      search
    }
  });
  return res.data;
};


export const getContentById = async (id) => {
  const res = await api.get(`/contents/${id}`);
  return res.data;
};

export const getLatestContents = async (limit = 5) => {
  const res = await api.get("/contents", {
    params: { limit }
  });
  return res.data;
};
