// Mock data
export const mockWorkshops = [
  { id: 1, title: 'Soil Contamination & Phytoremediation', date: '2025-08-08', image: '/img/Untitled design (42).png', descr: 'An expert workshop on soil contamination...', report: '/files/report1.pdf', type: 'workshop'},
  { id: 2, title: 'Historical Evolution of Water Management', date: '2025-07-26', image: '/img/Untitled design (22).png', descr: 'A symposium about the history of water management...', report: '/files/report2.pdf', type: 'events'},
  { id: 3, title: 'National Water Resources Management Strategy', date: '2025-07-15', image: '/img/Untitled design (23).png', descr: 'Consultation session report.', report: '/files/report3.pdf', type: 'report'},
  { id: 4, title: 'Advocacy & Conflict Resolution', date: '2025-07-11', image: '/img/Untitled design (25).png', descr: 'Workshop on advocacy and conflict resolution', report: '/files/report4.pdf', type: 'workshop'}
];

// Helper function
export function formatDate(d) {
  if (!d) return '';
  try { 
    return new Date(d).toLocaleDateString(); 
  } catch (e) { 
    return d; 
  }
}
