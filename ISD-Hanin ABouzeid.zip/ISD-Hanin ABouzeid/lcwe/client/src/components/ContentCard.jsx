import { Link } from "react-router-dom";
import '../index.css';
import 'bootstrap-icons/font/bootstrap-icons.css';
import 'bootstrap/dist/css/bootstrap.min.css';
import 'bootstrap/dist/js/bootstrap.bundle.min';

export default function ContentCard({ item }) {
  // If type is "project", go to project details route
  const link =
    item.type === "project"
      ? `/project/${item.public_id}`
      : `/content/${item.public_id}`;

  return (
    <Link
      to={link}
      className="col-md-4 wow slideInUp text-decoration-none text-reset"
    >
      <div className="blog-item rounded overflow-hidden">
        <div className="blog-img position-relative overflow-hidden">
          <img
            src={`http://localhost:5000/uploads/images/${item.image}`}
            alt={item.title}
            loading="lazy"
          />
          <a className="position-absolute top-0 start-0 bg-primary text-white rounded-end mt-5 py-2 px-4">
            {item.type.charAt(0).toUpperCase() + item.type.slice(1)}
          </a>
        </div>
        <div className="p-4">
          <div className="d-flex mb-3">
            <small>
              <i className="far fa-calendar-alt text-primary me-2"></i>
              <b>{item.type} Date: </b>
              {item.date && (
                <p className="date">
                  {new Date(item.date).toLocaleDateString()}
                </p>
              )}
            </small>
          </div>
          <h4 className="mb-3">{item.title}</h4>
        </div>
      </div>
    </Link>
  );
}
