import React, { useEffect, useState } from 'react';
import { BrowserRouter as Router, Routes, Route, Link, useParams, useNavigate } from 'react-router-dom';
import '../index.css';

function Topbar() {
    
    const Facebook = 'https://www.facebook.com/profile.php?id=61574464090246';
    const Instagram = 'https://www.instagram.com/lcwe_lb/';
    const Youtube = 'https://www.youtube.com/@LCWE-LB';
    const Linkedin = 'https://www.linkedin.com/company/lcwe/posts/?feedView=all&viewAsMember=true';
    return (
        <div className="container-fluid px-5 d-none d-lg-block" style={{ backgroundColor:"#15415c"}}>
            <div className="row gx-0">
                <div className="col-lg-8 text-center text-lg-start mb-2 mb-lg-0">
                    <div className="d-inline-flex align-items-center" style={{height:45}}>
                        <small className="me-3 text-light"><i className="bi bi-geo-alt me-2"></i>Kfarjouz, Nabatieh, Lebanon</small>
                        <small className="text-light"><i className="bi bi-envelope-open me-2"></i>lcwe.officiallb@gmail.com</small>
                    </div>
                </div>
                <div className="col-lg-4 text-center text-lg-end">
                    <div className="d-inline-flex align-items-center" style={{height:45}}>
                        <a href={Facebook} className="btn btn-sm btn-outline-light btn-sm-square rounded-circle me-2"><i className="bi bi-facebook"></i></a>
                        <a href={Linkedin} className="btn btn-sm btn-outline-light btn-sm-square rounded-circle me-2"><i className="bi bi-linkedin"></i></a>
                        <a href={Instagram} className="btn btn-sm btn-outline-light btn-sm-square rounded-circle me-2"><i className="bi bi-instagram"></i></a>
                        <a href={Youtube} className="btn btn-sm btn-outline-light btn-sm-square rounded-circle"><i className="bi bi-youtube"></i></a>
                    </div>
                </div>
            </div>
        </div>
    );
}

export default Topbar;