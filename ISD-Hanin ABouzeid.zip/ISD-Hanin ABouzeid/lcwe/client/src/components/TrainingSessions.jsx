export default function TrainingSessions({ sessions }) {
  return (
    <div>
      <h3>Sessions</h3>
      {sessions.map((s) => (
        <div key={s.id}>
          <h4>{s.title}</h4>
          <p>{s.descr}</p>
          <p>{s.trainer}</p>
          <a href={s.link}>Join</a>
        </div>
      ))}
    </div>
  );
}
