import { MapContainer, TileLayer, FeatureGroup } from "react-leaflet";
import { EditControl } from "react-leaflet-draw";
import L from "leaflet";
import "leaflet/dist/leaflet.css";
import "leaflet-draw/dist/leaflet.draw.css";

export default function FieldMap({ onAreaCalculated }) {
  const handleCreated = (e) => {
    const layer = e.layer;
    const latlngs = layer.getLatLngs()[0];

    // Calculate area in m²
    const area_m2 = L.GeometryUtil.geodesicArea(latlngs);

    onAreaCalculated(area_m2);
  };

  return (
    <div>
      <h5 id="area">Draw Field on Map</h5>

      <MapContainer
        center={[33.38, 35.50]} // Lebanon center
        zoom={13}
        style={{ height: "300px", width: "100%" }}
      >
        <TileLayer
          attribution="&copy; OpenStreetMap contributors"
          url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
        />

        <FeatureGroup>
          <EditControl
            position="topright"
            onCreated={handleCreated}
            draw={{
              rectangle: true,
              polygon: true,
              circle: false,
              marker: false,
              polyline: false,
            }}
          />
        </FeatureGroup>
      </MapContainer>
    </div>
  );
}
