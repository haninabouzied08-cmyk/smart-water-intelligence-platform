import React from "react";
import "../index.css"; // Make sure your spinner CSS is included

const Spinner = ({ show }) => {
  return (
    <div id="spinner" className={show ? "show" : ""}>
      <div className="spinner"></div>
    </div>
  );
};

export default Spinner;
