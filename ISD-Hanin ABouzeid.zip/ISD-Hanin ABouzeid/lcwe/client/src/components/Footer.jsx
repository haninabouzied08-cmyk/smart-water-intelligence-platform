import React, { useEffect, useState } from 'react';
import { BrowserRouter as Router, Routes, Route, Link, useParams, useNavigate } from 'react-router-dom';
import '../index.css';

function Footer() {

    const Facebook = 'https://www.facebook.com/profile.php?id=61574464090246';
    const Instagram = 'https://www.instagram.com/lcwe_lb/';
    const Youtube = 'https://www.youtube.com/@LCWE-LB';
    const Linkedin = 'https://www.linkedin.com/company/lcwe/posts/?feedView=all&viewAsMember=true';
    const Email = 'lcwe.officiallb@gmail.com';

    return (
        <>
            <footer id="footer" data-wow-delay="0.1s">
                <div className="footer-top">
                    <div className="container">
                        <div className='row'>
                            <div className="col-lg-3 col-md-6 footer-contact">
                                <h3>LCWE</h3>
                                <p>
                                    Kfarjouz <br />
                                    Nabatieh<br />
                                    Lebanon <br /><br />
                                    <strong>Email:</strong> info@lcwe-lb.com<br />
                                </p>
                            </div>
                            <div class="col-lg-2 col-md-6 footer-links">
                                <h4>Useful Links</h4>
                                <ul>
                                <li><Link to='./' className="text-decoration-none text-reset"><i className="bi bi-chevron-right"></i> Home</Link></li>
                                <li><Link to='./about' className="text-decoration-none text-reset"><i className="bi bi-chevron-right"></i> About Us</Link></li>
                                <li><Link to='./contact' className="text-decoration-none text-reset"><i className="bi bi-chevron-right"></i> Contact Us</Link></li>
                                <li><Link to='./' className="text-decoration-none text-reset"><i className="bi bi-chevron-right"></i> LCWE Team</Link></li>
                                <li><Link to='./' className="text-decoration-none text-reset"><i className="bi bi-chevron-right"></i> Equipments</Link></li>
                                </ul>
                            </div>
                            <div class="col-lg-3 col-md-6 footer-links">
                                <h4>Pages</h4>
                                <ul>
                                <li><Link to='./' className="text-decoration-none text-reset"><i className="bx bx-chevron-right"></i> Joining Us</Link></li>
                                <li><Link to='./' className="text-decoration-none text-reset"><i className="bx bx-chevron-right"></i> Upcoming Events</Link></li>
                                </ul>
                            </div>
                            <div className="col-lg-4 col-md-6 footer-newsletter">
                                <h4>Join Our Newsletter</h4>
                                <p>
                                    Subscribe to receive email updates on new activities, workshops, training courses and more.
                                </p>
                                <form 
                                // onSubmit={(e) => {
                                //     e.preventDefault();
                                //     const email = e.target.email.value;
                                //     console.log("Subscribed with:", email);
                                //     }}
                                    method="post"
                                >
                                    <input type="email" name="email" placeholder="Your Email (Required)" required />
                                    <input type="submit" value="Subscribe" />
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
                <div className="container d-md-flex py-4">
                    <div className="me-md-auto text-center text-md-start">
                        <div className="copyright">
                            &copy; Copyright <strong><span>The Lebanese Center for Water and Environment</span></strong>. All Rights Reserved
                        </div>
                    </div>
                    <div className="social-links text-center text-md-right pt-3 pt-md-0">
                        <a href={Youtube} className="twitter"><i className="bi bi-youtube"></i></a>
                        <a href={Facebook} className="facebook"><i className="bi bi-facebook"></i></a>
                        <a href={Instagram} className="instagram"><i className="bi bi-instagram"></i></a>
                        <a href={Linkedin} class="linkedin"><i className="bi bi-linkedin"></i></a>
                    </div>
                </div>
            </footer>
        </>
    );
}

export default Footer;