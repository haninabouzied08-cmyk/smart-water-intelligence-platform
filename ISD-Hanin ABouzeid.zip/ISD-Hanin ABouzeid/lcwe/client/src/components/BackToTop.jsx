import React, { useEffect, useState } from "react";
import "../index.css";
import 'bootstrap-icons/font/bootstrap-icons.css';

const BackToTop = () => {
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    const toggleVisibility = () => {
      if (window.pageYOffset > 100) {
        setVisible(true);
      } else {
        setVisible(false);
      }
    };

    window.addEventListener("scroll", toggleVisibility);
    return () => window.removeEventListener("scroll", toggleVisibility);
  }, []);

  const scrollToTop = () => {
    window.scrollTo({
      top: 0,
      behavior: "smooth",
    });
  };

  return (
    <button
      className="back-to-top align-items-center justify-content-center"
      style={{ display:visible ? "block" : "none" }}
      onClick={scrollToTop}
    >
      <i class="bi bi-arrow-up-short"></i>
    </button>
  );
};

export default BackToTop;
