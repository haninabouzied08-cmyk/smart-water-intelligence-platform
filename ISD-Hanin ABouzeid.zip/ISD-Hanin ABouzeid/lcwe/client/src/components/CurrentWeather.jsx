import React, { useEffect, useState } from "react";
import "../index.css";
import api from "../api/api";
import 'bootstrap/dist/css/bootstrap.min.css';
import { Container, Row, Col, Card } from "react-bootstrap";
import { FaTint, FaSun, FaWind, FaCloudRain } from "react-icons/fa";

const CurrentWeather = () => {
  const [irrigation, setIrrigation] = useState(null);
  const [weather, setWeather] = useState(null);

  useEffect(() => {
    const fetchIrrigation = () => {
      api.get("/irrigation/today")
        .then(res => {
          if (res.data) {
            setIrrigation(res.data);
          }
        })
        .catch(console.error);
    };

    const fetchWeather = () => {
      api.get("/weather/current")
        .then(res => setWeather(res.data))
        .catch(console.error);
    };

    // Initial fetch
    fetchIrrigation();
    fetchWeather();

    // Poll irrigation every 5 seconds (AI background job)
    const irrigationInterval = setInterval(fetchIrrigation, 5000);

    return () => clearInterval(irrigationInterval);
  }, []);


  if (!weather && !irrigation)
    return <p>Loading dashboard...</p>;


  if (!irrigation) {
    return (
      <p style={{ textAlign: "center" }}>
        No irrigation data yet. Please complete the SWIP form to generate irrigation data.
      </p>
    );
  }


  return (
    <div className="dashboard-bg">
      <Container className="py-5">
        <h2 className="text-center text-white mb-4">
          Irrigation Monitoring Dashboard
        </h2>
        <h2>My Irrigation Schedule</h2>
      {history.length === 0 ? (
        <p>No irrigation records found. Please complete the SWIP form first.</p>
      ) : (
        <>
        {history.map((row) => (
          <>
        <Row className="mb-4">
          <Col md={6}>
            <Card className="info-card blue-card">
              <Card.Body>
                <h5>Today's Irrigation</h5>
                <h1>
                  <FaTint />{" "}
                  {Math.round(row.irrigation_liters)} Liters
                </h1>
                <p>Water Applied</p>
                <p>Date: {new Date(row.irrigation_date).toLocaleString()}</p>
              </Card.Body>
            </Card>
          </Col>

          <Col md={6}>
            <Card className="info-card green-card">
              <Card.Body>
                <h5>Live Weather Data</h5>
                <h1>
                  <FaSun /> {row.temperature}°C
                </h1>
                <p>
                  <FaWind /> Wind: {row.wind_speed} m/s
                </p>
                <p>Humidity: {row.humidity}%</p>
                <p>
                  <FaCloudRain /> Rainfall: {row.rainfall} mm
                </p>
              </Card.Body>
            </Card>
          </Col>
        </Row>

        /* Bottom Cards */
        <Row>
          <Col md={3}>
            <Card className="small-card">
              <Card.Body>
                <h6>Soil Moisture</h6>
                <h3>{row.soil_moisture}%</h3>
              </Card.Body>
            </Card>
          </Col>

          <Col md={3}>
            <Card className="small-card">
              <Card.Body>
                <h6>Sunlight</h6>
                <h3>—</h3>
              </Card.Body>
            </Card>
          </Col>

          <Col md={3}>
            <Card className="small-card">
              <Card.Body>
                <h6>Air Pressure</h6>
                <h3>—</h3>
              </Card.Body>
            </Card>
          </Col>

          <Col md={3}>
            <Card className="small-card crop-card">
              <Card.Body>
                <h6>Recommended Crops</h6>
                <div className="crops">
                  <span>🌽 Corn</span>
                  <span>🍅 Tomato</span>
                  <span>🥬 Lettuce</span>
                </div>
              </Card.Body>
            </Card>
          </Col>
        </Row>

        <Row className="mt-3">
          <small className="text-white">
            Weather updated: {new Date(row.created_at).toLocaleString()}
          </small>
        </Row>
        </>
        ))}
        </>
      )}
      </Container>
    </div>
  );
}

export default CurrentWeather;
