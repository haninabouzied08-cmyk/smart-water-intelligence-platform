import { useState } from "react";

export default function FieldAreaForm({ onAreaCalculated }) {
  const [width, setWidth] = useState("");
  const [height, setHeight] = useState("");
  const [area, setArea] = useState(null);

  const calculateArea = () => {
    const w = parseFloat(width);
    const h = parseFloat(height);

    if (w <= 0 || h <= 0) {
      alert("Width and height must be positive numbers");
      return;
    }

    const area_m2 = w * h;
    setArea(area_m2);

    // Send value to parent component
    onAreaCalculated(area_m2);
  };

  return (
    <div>
      <h5>Manual Field Area</h5>

      <div className="row g-3" id="area">
        <div className="col-md-5">
          <label htmlFor="width" className="form-label">Width (m)</label>
          <input
            id="width"
            type="number"
            value={width}
            className="form-control"
            placeholder="Width"
            onChange={(e) => setWidth(e.target.value)}
          />
        </div>

        <div className="col-md-5">
          <label htmlFor="height"  className="form-label" >Height (m)</label>
          <input
            type="number"
            id="height"
            value={height}
            className="form-control"
            placeholder="Height"
            onChange={(e) => setHeight(e.target.value)}
          />
        </div>

        <div className="col-md-2 mt-5">
          <button className="w-100 btn btn-primary btn-l p-2" onClick={calculateArea}>Calculate Area</button>
        </div>

      

      {area && (
        <p>
          <strong>Area:</strong> {area.toFixed(2)} m²
        </p>
      )}
      </div>
    </div>
  );
}
