import React from "react";
import { Navigate } from "react-router-dom";

const ProtectedIrrigationRoute = ({ children }) => {
  const token = localStorage.getItem("token");
  const swipCompleted = localStorage.getItem("swipCompleted");

  if (!token) {
    return <Navigate to="/login" replace />;
  }

  if (!swipCompleted) {
    return <Navigate to="/swip" replace />;
  }

  return children;
};

export default ProtectedIrrigationRoute;
