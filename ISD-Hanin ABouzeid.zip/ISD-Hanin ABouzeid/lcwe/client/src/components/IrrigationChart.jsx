import {
  Chart as ChartJS,
  LineElement,
  CategoryScale,
  LinearScale,
  PointElement,
  Tooltip,
  Legend
} from "chart.js";

import { Line } from "react-chartjs-2";

ChartJS.register(
  LineElement,
  CategoryScale,
  LinearScale,
  PointElement,
  Tooltip,
  Legend
);

export default function IrrigationChart({ data }) {
  const chartData = {
    labels: data.map(d => d.irrigation_date),
    datasets: [
      {
        label: "Irrigation (mm)",
        data: data.map(d => d.irrigation_mm),
        borderColor: "#4CAF50",
        backgroundColor: "rgba(76,175,80,0.2)",
        tension: 0.3,
        fill: true
      }
    ]
  };

  return <Line data={chartData} />;
}
