import React, { useEffect, useState } from 'react';
import { BrowserRouter as Router, Routes, Route, Link, useParams, useNavigate } from 'react-router-dom';
import '../index.css';
import Logo from '../assets/img/logo.png';
import 'bootstrap-icons/font/bootstrap-icons.css';

function Navbar() {
    const navigate = useNavigate();
    const isLoggedIn = localStorage.getItem("token");

    const logout = () => {
        localStorage.removeItem("token");
        navigate("/");
    };
    
    return (
        <nav className="navbar navbar-expand-lg">
            <div className='container'>
                <Link to="/" className="navbar-brand">
                    <img src={Logo} alt="LCWE" className="navbar-logo" />
                </Link>
                <button className="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarCollapse"  aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                    <span className="navbar-toggler-icon" />
                </button>
                <div className="collapse navbar-collapse" id="navbarCollapse">
                    <div className="navbar-nav ms-lg-5 me-lg-auto">
                        <Link to="/" className="nav-item nav-link">Home</Link>
                        <Link to="/about" className="nav-item nav-link">About LCWE</Link>
                        {/* <Link to="/projects" className="nav-item nav-link">Projects</Link> */}
                        <div className="nav-item dropdown">
                            <a href="#" className="nav-link dropdown-toggle" id="navbarLightDropdownMenuLink" role="button" data-bs-toggle="dropdown">Activities</a>
                            <div className="dropdown-menu dropdown-menu-light" aria-labelledby="navbarLightDropdownMenuLink">
                                <Link className="dropdown-item" to="/events">Events & Webinars</Link>
                                <Link className="dropdown-item" to="/training">Training Courses</Link>
                                <Link className="dropdown-item" to="/workshops">Workshops</Link>
                            </div>
                        </div>
                        <div className="nav-item dropdown">
                            <a href="#" className="nav-link dropdown-toggle" id="navbarLightDropdownMenuLink1" role="button" data-bs-toggle="dropdown">Resources</a>
                            <div className="dropdown-menu dropdown-menu-light"  aria-labelledby="navbarLightDropdownMenuLink1">
                                <Link className="dropdown-item" to="/publications">Publications</Link>
                                <Link className="dropdown-item" to="/reports">Reports</Link>
                                <Link className="dropdown-item" to="/blogs">Blogs</Link>
                            </div>
                        </div>
                    </div>
                    
                    {!isLoggedIn ? (
                    <Link to="/login" className="btn btn-primary py-2 px-4 ms-3">Sign In</Link>
                    ) : (
                    <>
                        <div className="d-none d-lg-block dropdown">
                            <a href='#'
                            className="navbar-icon bi-person smoothscroll dropdown-toggle dropdown-menu-light"
                            id="user" role="button"
                            data-bs-toggle="dropdown"
                            >
                            </a>
                            <div className="dropdown-menu dropdown-menu-light"  aria-labelledby="user">
                                <Link className="dropdown-item" to="/swip">Add Irrigation Schedule</Link>
                                <Link className="dropdown-item" to="/irrigation">Irrigation Schedule</Link>
                                <Link className="dropdown-item" to="/" onClick={logout}>Logout</Link>
                            </div>
                        </div>
                    </>
                    )}
                    <Link to="/contact" className="btn btn-primary py-2 px-4 ms-3">Contact Us</Link>
                </div>
            </div>
        </nav>
    );
}

export default Navbar;