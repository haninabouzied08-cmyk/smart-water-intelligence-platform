export default function SessionLinks({ link }) {
  if (!link) return null;

  const links = link
    .split(",")
    .map((l) => l.trim())
    .filter(Boolean)
    .map((url) => {
      // youtube.com/watch?v=VIDEO_ID
      if (url.includes("youtube.com/watch")) {
        const params = new URLSearchParams(new URL(url).search);
        const videoId = params.get("v");
        if (videoId) {
          return `https://www.youtube.com/embed/${videoId}`;
        }
      }

      // youtu.be/VIDEO_ID
      if (url.includes("youtu.be/")) {
        const videoId = url.split("youtu.be/")[1].split("?")[0];
        return `https://www.youtube.com/embed/${videoId}`;
      }

      return url; // fallback
    });

  return (
    <>
      <br />
      <p><strong>Links:</strong></p>

      {links.map((embedUrl, index) => (
        <iframe
          key={index}
          src={embedUrl}
          title={`Recorded Session ${index + 1}`}
          className="col-lg-9" 
          height="350px"
          allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
          allowFullScreen
        />
      ))}
    </>
  );
}
