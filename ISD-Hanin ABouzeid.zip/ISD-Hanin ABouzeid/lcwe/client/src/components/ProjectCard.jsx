import { Link } from "react-router-dom";
import '../index.css';
import 'bootstrap-icons/font/bootstrap-icons.css';
import 'bootstrap/dist/css/bootstrap.min.css';
import 'bootstrap/dist/js/bootstrap.bundle.min';
import { Accordion, Card } from "react-bootstrap";

export default function ContentCard({ item }) {
  const link = `/content/${item.public_id}`;
  console.log(item);

  return (
    <>
    <Link>
        <Accordion.Item eventKey={project.id} className="border-0"> 
            <Accordion.Header> 
                <div className="d-flex justify-content-between w-100 project-box"> 
                    <span> <h3>{project.acronym}</h3> <b>Title: </b> {project.title} </span> 
                    <span>▼</span> 
                </div>
            </Accordion.Header> 
            <Accordion.Body> 
                <div className="project-desc"> 
                    <b>Duration: </b> {project.duration} <br /> 
                    <b>Focus Region: </b> {project.location} <br /> 
                    <b>Partners: </b> {project.partner} <br /> 
                    <b>Funding: </b> {project.funding} <br /> 
                    <b>Goal: </b> {project.goal} <br /> 
                    {objectives.length > 0 && ( 
                        <> <p> <strong>Objective: </strong> </p> 
                        <ul> {objectives.map((objective, idx) => ( 
                            <li key={idx}>{objective}</li> ))} 
                        </ul> </> )} 
                    {activities.length > 0 && ( 
                        <> 
                        <p> <strong>Key Activities: </strong> </p> 
                        <ul> {activities.map((activity, idx) => ( 
                            <li key={idx}>{activity}</li> ))} 
                        </ul> </> )} 
                </div> 
            </Accordion.Body> 
        </Accordion.Item>
    </Link>
    </>
  );
}
