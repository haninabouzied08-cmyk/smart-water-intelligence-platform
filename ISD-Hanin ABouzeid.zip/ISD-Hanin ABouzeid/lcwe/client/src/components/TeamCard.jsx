import React, { useEffect, useState } from 'react';
import { BrowserRouter as Router, Routes, Route, Link, useParams, useNavigate } from 'react-router-dom';
import '../index.css';
import Logo from '../assets/img/logo.png';
import 'bootstrap-icons/font/bootstrap-icons.css';

function TeamCard() {
    return (
        <>
        <div class="row g-4">
            <div class="col-lg-3 col-md-6 wow fadeInUp" data-wow-delay="0.1s">
                <div class="team-item">
                        <div class="overflow-hidden">
                            <a href="">
                                <img class="img-fluid" src="" alt="" />
                            </a>
                        </div>
                        <div class="position-relative d-flex justify-content-center" style="margin-top: -23px;">
                            <div class="bg-light d-flex justify-content-center pt-2 px-1">
                                <a class="btn btn-sm-square btn-primary mx-1" href=""><i class="fab fa-facebook-f"></i></a>
                                <a class="btn btn-sm-square btn-primary mx-1" href=""><i class="fab fa-twitter"></i></a>
                                <a class="btn btn-sm-square btn-primary mx-1" href=""><i class="fab fa-instagram"></i></a>
                            </div>
                        </div>
                        <div class="text-center p-4">
                            <a href="teamdetail.php?type=team&id=<?php echo urlencode($encrypted_id); ?>">
                                <h5 class="mb-0"></h5>
                            </a>
                            <small></small>
                        </div>
                    </div>
            </div>
        </div>
        </>
    );

}

export default TeamCard;