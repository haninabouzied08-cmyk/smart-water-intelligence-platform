import React, { useState, useEffect, useRef } from "react";
import { useNavigate, Navigate } from "react-router-dom";
import api from "../api/api";
import "../index.css";
import calculatorImage from "../assets/img/crops.png";
import "leaflet/dist/leaflet.css";
import Navbar from "../components/Navbar";
import FieldAreaForm from "../components/FieldAreaForm";
import FieldMap from "../components/FieldMap";
import markerIcon from "leaflet/dist/images/marker-icon.png";
import markerShadow from "leaflet/dist/images/marker-shadow.png";
import { Helmet } from 'react-helmet';
import farmer from '../assets/img/farmer.png';

const SWIP = () => {

  const [location, setLocation] = useState(null);
  const [cropTypes, setCropTypes] = useState([]);
  const [selectedType, setSelectedType] = useState("");
  const [cropNames, setCropNames] = useState([]);
  const [selectedCrop, setSelectedCrop] = useState("");
  const [soilType, setSoilType] = useState("");
  const [cropPhase, setCropPhase] = useState("");
  const [area, setArea] = useState(null);

  const mapRef = useRef();

  const soilTypes = [
    { value: "sand", label: "Sandy" },
    { value: "clay", label: "Clay" },
    { value: "loam", label: "Loamy" },
  ];

  const cropPhases = [
    { value: "initial", label: "Initial" },
    { value: "mid", label: "Middle" },
    { value: "end", label: "End" },
  ];

  const navigate = useNavigate();

  useEffect(() => {
  api
    .get("/crops/crop-types")
    .then(res => setCropTypes(res.data))
    .catch(err => console.error(err));
  }, []);

  useEffect(() => {
    if (location && mapRef.current) {
      mapRef.current.setView([location.lat, location.lng], 12);
    }
  }, [location]);



  const handleTypeChange = async (e) => {
    const type = e.target.value;
    setSelectedType(type);
    setSelectedCrop(""); // reset selected crop

    if (!type) {
      setCropNames([]);
      return;
    }

    try {
      const res = await api.get(`/crops/by-type/${type}`);
      setCropNames(res.data);
      console.log("Crops received:", res.data);
    } catch (err) {
      console.error("Failed to fetch crops by type:", err);
      setCropNames([]);
    }
  };


  // 📤 Send data to backend
  const handleSubmit = async (e) => {
    e.preventDefault();

    if (!area || !selectedType || !selectedCrop || !soilType || !cropPhase) {
      alert("Please select area, crop type, crop name, soil type, and crop phase");
      return;
    }

    try {
      await api.post("/swip/swip-request", {
        area_m2: area,
        crop_type: selectedType,
        crop_name: selectedCrop,

        soil_type: soilType,
        crop_phase: cropPhase,
      });

      localStorage.setItem("swipCompleted", "true");
      navigate("/irrigation");

    } catch (err) {
      console.error(err);
      alert(err.response?.data?.error || "Submission failed");
    }
  };


  return (
    <>
     <Helmet>
        <title>LCWE | Irrigation</title>
      </Helmet>
      <div className="container-fluid position-relative p-3">
        <Navbar />
      </div>

    <div className="container-fluid wow fadeInUp" data-wow-delay="0.1s">
            <div className="section-title text-center position-relative pb-3 mb-5 mx-auto" style={{maxWidth:600}}>
                <h5 className="fw-bold text-primary text-uppercase">swip</h5>
                <h1 className="mb-0">Smart Water Intelligence Platform</h1>
            </div>
            <div className="row g-5 justify-content-center align-items-center">
                <div className="col-lg-10 col-md-6 wow slideInUp">
                    <p className="mb-5" style={{textAlign:'justify'}}>
                        Smart Water Intelligence Platform (SWIP) is a digital decision-support tool developed to help farmers, researchers, and water managers make informed choices about irrigation and crop water use.
                        <br /><br />
                        The platform combines user-provided field information with smart data analysis to offer insights that support efficient water use, sustainable agriculture, and climate-resilient farming practices. By sharing basic information about your location and crop type, SWIP helps improve understanding of water needs under different environmental conditions.
                    </p>
                </div>
                

            </div>
    </div>

    <section className="section-padding section-bg">
                <div className="container">
                    <div className="row">

                        <div className="col-lg-6 col-md-6 col-12 mt-3 mb-4 mb-lg-0">
                            <div>
                              <div className="row g-0 mb-3">
                        <div className="section-title section-title-sm position-relative pb-3 mb-4">
                            <h3 className="mb-0">SWIP is designed to:</h3>
                        </div>
                        <div className="col-sm-12 wow zoomIn" data-wow-delay="0.2s">
                            <h6 className="mb-3" style={{textAlign:'justify'}}><i className="bi bi-check text-primary me-3"></i>Support smarter irrigation planning</h6>
                            <h6 className="mb-3" style={{textAlign:'justify'}}><i className="bi bi-check text-primary me-3"></i>Reduce water waste and improve water productivity</h6>
                        </div>
                        <div className="col-sm-12 wow zoomIn" data-wow-delay="0.4s">
                            <h6 className="mb-3" style={{textAlign:'justify'}}><i className="bi bi-check text-primary me-3"></i>Enhance resilience to climate variability</h6>
                            <h6 className="mb-3" style={{textAlign:'justify'}}><i className="bi bi-check text-primary me-3"></i>Contribute to sustainable water and agricultural management in Lebanon</h6>
                        </div>
                    </div>
                    <p className="mb-5" style={{textAlign:'justify'}}>
                        All data provided through this platform is used for research and decision-support purposes only and aims to support better water governance and sustainable development initiatives.
                    </p>
                            </div>
                        </div>

                        <div className="col-lg-6 col-md-6 col-12 mt-lg-3">
                            <div className="custom-block custom-block-overlay">
                                <div className="d-flex flex-column h-100">
                                    <img src={farmer} className="custom-block-image img-fluid" alt="" />
                                    <div className="image-overlay"></div>

                                    <div className="custom-block-overlay-text d-flex">
                                        <div>
                                            <h3 className="mb-0 text-white">Today’s Irrigation Overview</h3>

                                            <p className="mb-5 text-white"  style={{textAlign:'justify'}}>View today’s weather conditions and the recommended irrigation amount for your field.</p>
                                            <button
                                              type="button"
                                              className="btn btn-primary py-2 px-4 ms-3"
                                              onClick={() => navigate("/today-irrigation")}
                                            >
                                              View Today's Irrigation
                                            </button>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                    </div>
                </div>
            </section>

    <div className="container">
        <div className="order-md-1">
          <div className="section-title section-title-sm position-relative pb-3 mb-4">
            <h3 className="mb-0">SWIP – Smart Irrigation Input Form</h3>
          </div>
          <form onSubmit={handleSubmit}>
            <div className="row g-3">
              <div>
                <label htmlFor="area" className="form-label">Field Area Definition Method</label>
                <FieldAreaForm onAreaCalculated={(area) => setArea(area)} />
                <div className="col-md-6 ">
                  <FieldMap onAreaCalculated={(area) => setArea(area)} />
                </div>
                {area && (
                  <p style={{ marginTop: "10px" }}>
                  📐 <strong>Field Area:</strong> {area.toFixed(2)} m²
                  </p>
                )}
              </div>

              <div className="col-md-6">
                <label htmlFor="chooseOption" className="form-label">Crop Type</label>
                <select id="chooseOption" className="form-select" onChange={handleTypeChange} value={selectedType} required>
                  <option value="">-- Select Crop Type --</option>
                      {cropTypes.map((type, i) => (
                        <option key={i} value={type}>{type}</option>
                      ))}
                </select>
              </div>
              {selectedType && (
              <>
              <div className="col-md-6">
                <label htmlFor="chooseOption1" className="form-label">Crop Name</label>
                <select id="chooseOption1" className="form-select" value={selectedCrop} onChange={(e) => setSelectedCrop(e.target.value)} required>
                  <option value="">-- Select Crop Name --</option>
                  {cropNames.map((crop, i) => (
                    <option key={i} value={crop}>{crop}</option>
                  ))}
                </select>
              </div>
              </>
              )}
              <div className="col-md-6">
                <label htmlFor="soilType" className="form-label">Soil Type</label>
                <select
                  id="soilType"
                  className="form-select"
                  value={soilType}
                  onChange={(e) => setSoilType(e.target.value)}
                  required
                >
                  <option value="">-- Select Soil Type --</option>
                  {soilTypes.map((type, i) => (
                  <option key={i} value={type.value}>
                  {type.label}
                  </option>
                  ))}
                  </select>
              </div>

            <div className="col-md-6">
                <label htmlFor="cropPhase" className="form-label">Crop phase</label>
                <select
                  id="cropPhase"
                  className="form-select"
                  value={cropPhase}
                  onChange={(e) => setCropPhase(e.target.value)}
                  required
                >
                  <option value="">-- Select Crop Phase --</option>
                  {cropPhases.map((type, i) => (
                    <option key={i} value={type.value}>
                      {type.label}
                    </option>
                  ))}
                  </select>
              </div>
            </div>
            <div className="col-lg-10 col-md-6 m-5">
              <button className="w-100 btn btn-primary btn-l p-2" type="submit">Submit</button>
            </div>
          </form>
        </div>
    </div>
    </>
  );
};

export default SWIP;
