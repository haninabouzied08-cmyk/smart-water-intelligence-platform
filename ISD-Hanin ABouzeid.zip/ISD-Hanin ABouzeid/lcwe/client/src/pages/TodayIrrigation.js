import React, { useEffect, useState } from "react";
import api from "../api/api";
import { Helmet } from 'react-helmet';
import "../index.css";
import Navbar from "../components/Navbar";
import { Container, Row, Col, Card } from "react-bootstrap";
import { FaTint, FaSun, FaWind, FaCloudRain, FaStar } from "react-icons/fa";
import { WiTime3, WiHumidity } from "react-icons/wi";
import { GiSpeedometer, GiRadiations } from "react-icons/gi";
import { TiWaves } from "react-icons/ti";
import 'bootstrap/dist/css/bootstrap.min.css';

function TodayIrrigation() {
  const [data, setData] = useState(null);

  useEffect(() => {
    const fetchToday = async () => {
      try {
        const res = await api.get("/irrigation/today");
        console.log("API response:", res.data);
        setData(res.data);
      } catch (err) {
        console.error("Failed to fetch today's irrigation:", err);
      }
    };
    fetchToday();
  }, []);

  if (!data) return <p>Loading today's irrigation...</p>;

  return (
    <>
    <Helmet>
      <title>LCWE | Today's Irrigation</title>
    </Helmet>
    <div className="container-fluid position-relative p-0">
      <Navbar />
    </div>
    <Container className="py-5">
      <Row className="mb-4"> 
        <Col> 
              <h4>Hello, your <strong>{data.crop_name}</strong> is in phase <strong>{data.crop_phase}</strong>. </h4> 
              {data.irrigation_liters > 0 ? ( 
                <p>You have to irrigate <strong>{data.irrigation_liters.toFixed(2)} Liters</strong> today. </p> 
                ) : ( 
                <p>There is no need to irrigate today. </p> 
              )} 
          </Col> 
      </Row>
      <Row className="mb-4">
          <Col md={6}>
            <Card className="info-card blue-card">
              <Card.Body>
                <h5>Today's Irrigation</h5>
                <h1>
                  <FaTint />{" "}
                  {data.irrigation_liters.toFixed(2)} Liters
                </h1>
                <p><WiTime3 /> Date: {new Date(data.created_at).toLocaleString()}</p>
              </Card.Body>
            </Card>
          </Col>

          <Col md={6}>
            <Card className="info-card green-card">
              <Card.Body>
                <h5>Live Weather Data</h5>
                <h1>
                  <FaSun /> {(data.temperature).toFixed(2)}°C
                </h1>
                <p>
                  <FaWind /> Wind: {(data.wind_speed).toFixed(2)} m/s
                </p>
                <p>
                  <WiHumidity /> Humidity: {(data.humidity).toFixed(2)}%
                </p>
              </Card.Body>
            </Card>
          </Col>
        </Row>
        <Row>
          <Col md={3}>
            <Card className="small-card">
              <Card.Body>
                <h6><TiWaves /> Soil Moisture</h6>
                <h3>{(data.soil_moisture).toFixed(2)}%</h3>
              </Card.Body>
            </Card>
          </Col>

          <Col md={3}>
            <Card className="small-card">
              <Card.Body>
                <h6><GiRadiations /> Solar Radiation</h6>
                <h3>{(data.solar_radiation).toFixed(2)}</h3>
              </Card.Body>
            </Card>
          </Col>

          <Col md={3}>
            <Card className="small-card">
              <Card.Body>
                <h6><GiSpeedometer /> Air Pressure</h6>
                <h3>{(data.pressure).toFixed(2)}</h3>
              </Card.Body>
            </Card>
          </Col>

          <Col md={3}>
            <Card className="small-card">
              <Card.Body>
                <h6><FaCloudRain /> Rainfall</h6>
                <h3>{(data.rainfall).toFixed(2)} mm</h3>
              </Card.Body>
            </Card>
          </Col>
        </Row>

        <Row className="mt-3 align-items-center justify-content-center">
          <Col md={5}>
            <Card className="small-card crop-card">
              <Card.Body>
                <h5><FaStar /> Recommended Crops</h5>
                <div className="crops">
                  <span>🌽 Corn</span>
                  <span>🍅 Tomato</span>
                  <span>🥬 Lettuce</span>
                </div>
              </Card.Body>
            </Card>
          </Col>
        </Row>
    </Container>
    </>
  );
}

export default TodayIrrigation;
