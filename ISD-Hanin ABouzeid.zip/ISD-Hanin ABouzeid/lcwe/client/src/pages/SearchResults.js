import { useEffect, useState } from "react";
import { useLocation } from "react-router-dom";
import { searchContents } from "../api/search.api";
import ContentCard from "../components/ContentCard";
import { Helmet } from 'react-helmet';
import Navbar from "../components/Navbar";

export default function SearchResults() {
  const { search } = useLocation();
  const params = new URLSearchParams(search);
  const keyword = params.get("keyword");

  const [items, setItems] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");

  useEffect(() => {
    const load = async () => {
      try {
        setLoading(true);
        const results = await searchContents(keyword);
        setItems(results);
      } catch (err) {
        console.error(err);
        setError("Search failed.");
      } finally {
        setLoading(false);
      }
    };
    if (keyword) load();
  }, [keyword]);

  if (loading) return <p>Loading...</p>;
  if (error) return <p style={{ color: "red" }}>{error}</p>;

  return (
    <>
    <Helmet>
        <title>LCWE | Search</title>
      </Helmet>
      <div className="container-fluid position-relative p-0">
        <Navbar />
      </div>
    <div className="container py-5">
      <h2>Search Results for "{keyword}"</h2>
      <div className="row g-5 mt-4">
        {items.length > 0 ? (
          items.map((item) => (
            <ContentCard key={item.public_id} item={item} />
          ))
        ) : (
          <p>No results found.</p>
        )}
      </div>
    </div>
    </>
  );
}
