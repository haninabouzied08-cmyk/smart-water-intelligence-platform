import 'bootstrap/dist/css/bootstrap.min.css';
import 'bootstrap/dist/js/bootstrap.bundle.min';
import 'bootstrap-icons/font/bootstrap-icons.css';
import React from "react";
import { BrowserRouter as Router, Routes, Route, Link, useParams, useNavigate } from 'react-router-dom';
import Navbar from "../components/Navbar";
import CurrentWeather from "../components/CurrentWeather";
import "../index.css";
import { Helmet } from 'react-helmet';

const Irrigation = () => {
  return (
    <>
       <Helmet>
        <title>LCWE | Irrigation</title>
      </Helmet>
      <div className="container-fluid position-relative p-0">
        <Navbar />
      </div>

      <div className="weather-app">
        <CurrentWeather />
      </div>
    </>
  );
};

export default Irrigation;
