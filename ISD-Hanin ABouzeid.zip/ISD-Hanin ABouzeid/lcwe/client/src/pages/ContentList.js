import { useEffect, useState } from "react";
import { getPublicContents } from "../api/publicContent.api";
import ContentCard from "../components/ContentCard";
import Navbar from "../components/Navbar";
import "../index.css";
import 'bootstrap/dist/css/bootstrap.min.css';
import 'bootstrap/dist/js/bootstrap.bundle.min';
import 'bootstrap-icons/font/bootstrap-icons.css';
import { Helmet } from 'react-helmet';

export default function ContentList({ type }) {
  const [items, setItems] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");

  useEffect(() => {
    let mounted = true;

    const load = async () => {
      try {
        setLoading(true);
        setError("");

        const data = await getPublicContents(type);

        if (mounted) {
          setItems(data);
        }
      } catch (err) {
        console.error(err);
        setError("Failed to load content.");
      } finally {
        if (mounted) setLoading(false);
      }
    };

    load();

    return () => {
      mounted = false;
    };
  }, [type]);
  console.log(items);


  if (loading) {
    return <p style={{ textAlign: "center" }}>Loading...</p>;
  }

  if (error) {
    return <p style={{ textAlign: "center", color: "red" }}>{error}</p>;
  }

  if (!items.length) {
    return <p style={{ textAlign: "center" }}>No content found.</p>;
  }

  return (
    <>
    <Helmet>
      <title>LCWE | {type}</title>
    </Helmet>
    <div className="container-fluid position-relative p-0">
      <Navbar />
    </div>
    <div className="container-fluid py-5 wow fadeInUp">
      <div className="container py-5">
        <div className="col-lg-12">
          <div className="row g-5">
            {items.map((item) => (
              <ContentCard key={item.public_id} item={item} />
            ))}
          </div>
        </div>
      </div>
    </div>
    </>
  );
}
