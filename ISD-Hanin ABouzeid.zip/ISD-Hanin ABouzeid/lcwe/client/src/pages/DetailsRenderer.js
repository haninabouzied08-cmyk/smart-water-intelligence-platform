export default function DetailsRenderer({ type, details }) {
  if (!details) return null;

  switch (type) {
    case "blog":
      return details.link ? (
        <p>
          <a href={details.link} target="_blank" rel="noreferrer">
            Read full article
          </a>
        </p>
      ) : null;

    case "event":
    case "workshop":
    case "report":
      return details.report ? (
        <p>
          <a
            href={`http://localhost:5000/uploads/reports/${details.report}`}
            target="_blank"
            rel="noreferrer"
            className="btn btn-primary py-2 px-4"
          >
            View Full Report
          </a>
        </p>
      ) : null;

    case "publication":
      return (
        <div>
            <br></br>
            <h5 className="mb-4">Citation: </h5>
            <p>{details.citation}</p>
            <p>DOI: {details.doi && (
            <a href={details.doi} target="_blank" rel="noreferrer">
              {details.doi}
            </a>
            )}</p>
            <h5 className="mb-4">Keywords: </h5>
            <p>{details.keyword}</p>
        </div>
      );

    case "training":
      return (
        <>
        <h5 className="mb-4">Objectives: </h5>
        <p>{details.objective}</p>
        <h5 className="mb-4">Format: </h5>
        <p>{details.format}</p>
        </>
      );

    default:
      return null;
  }
}
