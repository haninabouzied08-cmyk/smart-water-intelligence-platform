import React, { useEffect, useState } from "react";
import api from "../api/api";
import { Helmet } from 'react-helmet';
import "../index.css";
import Navbar from "../components/Navbar";
import 'bootstrap/dist/css/bootstrap.min.css';

function IrrigationHistory() {
  const [history, setHistory] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchHistory = async () => {
      try {
        const res = await api.get("/irrigation/history");
        setHistory(res.data);
      } catch (err) {
        console.error("Failed to fetch irrigation history:", err);
      } finally {
        setLoading(false);
      }
    };
    fetchHistory();
  }, []);

  if (loading) return <p>Loading irrigation schedule...</p>;

  return (
    <>
    <Helmet>
      <title>LCWE | History Irrigation</title>
    </Helmet>
      <div className="container-fluid position-relative p-0">
        <Navbar />
      </div>

    
    <div className="container mt-5">
      
      <h2 className="mb-5">My Irrigation Schedule</h2>
      {history.length === 0 ? (
        <p>No irrigation records found. Please complete the SWIP form first.</p>
      ) : (
        <>
        <div className="">
          <div className="main-list">
            <span className="title">Date</span>
            <span className="title">ET0</span>
            <span className="title">Soil Moisture</span>
            <span className="title">Rainfall</span>
            <span className="title">Area m2</span>
            <span className="title">Irrigation (L)</span>
          </div>
        </div>
        {history.map((row) => (
          <div key={row.id} className="list-item">
            <span className="item item-title">{new Date(row.irrigation_date).toLocaleString()}</span>
            <span className="item">{(row.ET0).toFixed(2)}</span>
            <span className="item">{(row.soil_moisture).toFixed(2)}</span>
            <span className="item">{(row.rainfall).toFixed(2)}</span>
            <span className="item">{(row.area_m2).toFixed(2)}</span>
            <span className="item">{(row.irrigation_liters).toFixed(2)}</span>
          </div>
        ))}
        </>
      )}
    </div>
    </>
  );
}

export default IrrigationHistory;
