// Imports
import React, { useState, useEffect } from "react";
import { BrowserRouter as Router, Routes, Route, Link, useParams, useNavigate } from 'react-router-dom';
import Navbar from "../components/Navbar";
import "../index.css"; 
import 'bootstrap/dist/css/bootstrap.min.css';
import 'bootstrap/dist/js/bootstrap.bundle.min';
import 'bootstrap-icons/font/bootstrap-icons.css';
import Slider from 'react-slick';
import "slick-carousel/slick/slick.css";
import "slick-carousel/slick/slick-theme.css";
import { Helmet } from 'react-helmet';
import { getLatestContents } from "../api/contents.api";
import H1 from '../assets/img/header1.png';
import H2 from '../assets/img/header2.png';
import About from '../assets/img/about.png';
import ihe from '../assets/img/ihe.png';
import lu from '../assets/img/lu.png';
import mu from '../assets/img/mu.png';
import eco from '../assets/img/eco.png';
import nahr from '../assets/img/nahr.png';
import raed from '../assets/img/raed.png';
import instm1 from '../assets/img/instm.png';
import instm2 from '../assets/img/instm (1).png';
import oorbd from '../assets/img/OORBD.png';
import logo1 from '../assets/img/logo (1).png';
import tu from '../assets/img/tu.png';
import wu from '../assets/img/wu.png';

import img1 from '../assets/img/cat-1.jpg';
import img2 from '../assets/img/cat-2.jpg';
import img3 from '../assets/img/cat-3.jpg';
import img4 from '../assets/img/cat-4.jpg';

import LoginSignup from '../pages/Login';
import axios from 'axios';

const Home = () => {

  const partnersImages = [ihe, lu, mu, eco, nahr, raed, instm1, instm2, oorbd, logo1, tu, wu];
  const [keyword, setKeyword] = useState(""); 
  const navigate = useNavigate();
  const [announcements, setAnnouncements] = useState([]);

  const settings = {
    dots: true, // Show navigation dots
    infinite: true, // Enable infinite scrolling
    speed: 100, // Transition speed in milliseconds
    slidesToShow: 3, // Number of slides to show at a time
    slidesToScroll: 2 // Number of slides to scroll at a time
  };

  const logos = {
    dots: true, // Show navigation dots
    infinite: true, // Enable infinite scrolling
    speed: 100, // Transition speed in milliseconds
    slidesToShow: 9, // Number of slides to show at a time
    slidesToScroll: 5 // Number of slides to scroll at a time
  };

  const [activeTab, setActiveTab] = useState('tab1');

  const handleSearch = (e) => { 
    e.preventDefault(); 
    if (!keyword.trim()) return; 
    navigate(`/search?keyword=${encodeURIComponent(keyword)}`); 
};
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  
  const viewSWAP = async () => {
    try {
      const token = localStorage.getItem('token');
      const res = await axios.get('http://localhost:5000/swap', {
        headers: { Authorization: token }
      });
      alert(res.data.message);
    } catch (err) {
      alert('Access denied. Please login.');
    }
  };
  useEffect(() => {
    const load = async () => {
      try {
        const data = await getLatestContents(5);
        setAnnouncements(data);
      } catch (err) {
        console.error(err);
      }
    };
    load();
  }, []);

  return (
    <>
        <Helmet>
            <title>LCWE | Home</title>
        </Helmet>
        <div className="container-fluid position-relative p-0">
            <Navbar />
            <div id="header-carousel" className="carousel slide carousel-fade" data-bs-ride="carousel">
                <div className="carousel-inner">
                    <div className="carousel-item active">
                        <img className="w-100" src={H1} alt="Image"/>
                        <div className="overlay">
                            <div className="carousel-caption d-flex flex-column align-items-center justify-content-center">
                                <div className="p-3" style={{maxWidth:900}}>
                                    <h5 className="text-white text-uppercase mb-3 animated slideInDown">Welcome to LCWE</h5>
                                    <h1 className="display-5 text-white mb-md-4 animated zoomIn">Empowering Sustainable Water and Environmental Solutions in Lebanon</h1>
                                    <form onSubmit={handleSearch}
                                    className="custom-form mt-4 pt-2 mb-lg-0 mb-5"
                                    role="search">
                                        <div className="input-group input-group-lg">
                                            <span className="input-group-text bi-search" id="basic-addon1"></span>
                                            <input name="keyword" type="search" className="form-control" id="keyword" placeholder="Find blogs, events, trainings, projects..." aria-label="Search" value={keyword} onChange={(e) => setKeyword(e.target.value)} />
                                            <button type="submit" className="form-control">Search</button>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div className="carousel-item">
                        <img className="w-100" src={H2} alt="Image"/>
                        <div className="overlay">
                            <div className="carousel-caption d-flex flex-column align-items-center justify-content-center">
                                <div className="p-3" style={{maxWidth:900}}>
                                    <h5 className="text-white text-uppercase mb-3 animated slideInDown">Explore Our Work</h5>
                                    <h1 className="display-5 text-white mb-md-4 animated zoomIn">Discover Our Projects, Workshops, and Training Courses</h1>
                                    <form onSubmit={handleSearch}
                                    className="custom-form mt-4 pt-2 mb-lg-0 mb-5"
                                    role="search">
                                        <div className="input-group input-group-lg">
                                            <span className="input-group-text bi-search" id="basic-addon1"></span>
                                            <input name="keyword" type="search" className="form-control" id="keyword" placeholder="Find blogs, events, trainings, projects..." aria-label="Search" value={keyword} onChange={(e) => setKeyword(e.target.value)} />
                                            <button type="submit" className="form-control">Search</button>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <button className="carousel-control-prev" type="button" data-bs-target="#header-carousel"
                    data-bs-slide="prev">
                    <span className="carousel-control-prev-icon" aria-hidden="true"></span>
                    <span className="visually-hidden">Previous</span>
                </button>
                <button className="carousel-control-next" type="button" data-bs-target="#header-carousel"
                    data-bs-slide="next">
                    <span className="carousel-control-next-icon" aria-hidden="true"></span>
                    <span className="visually-hidden">Next</span>
                </button>
            </div>
        </div>

      <div className="container-fluid facts py-5 pt-lg-0">
        <div className="container py-5 pt-lg-0">
            <div className="row gx-0">
                <div className="col-lg-4 wow zoomIn" data-wow-delay="0.1s">
                    <div className="bg-primary shadow d-flex align-items-center justify-content-center p-4" style={{height:150}}>
                        <div className="bg-white d-flex align-items-center justify-content-center rounded mb-2" style={{width:60,height:60}}>
                            <i className="bi bi-people text-primary fs-2"></i>
                        </div>
                        <div className="ps-4">
                            <h5 className="text-white mb-0">Expert Members</h5>
                            <h1 className="text-white mb-0" data-toggle="counter-up">27</h1>
                        </div>
                    </div>
                </div>
                <div className="col-lg-4 wow zoomIn" data-wow-delay="0.3s">
                    <div className="bg-light shadow d-flex align-items-center justify-content-center p-4" style={{height:150}}>
                        <div className="bg-primary d-flex align-items-center justify-content-center rounded mb-2" style={{width:60,height:60}}>
                            <i className="bi bi-award text-white fs-2"></i>
                        </div>
                        <div className="ps-4">
                            <h5 className="text-primary mb-0">Years of Experience</h5>
                            <h1 className="mb-0" data-toggle="counter-up">8</h1>
                        </div>
                    </div>
                </div>
                <div className="col-lg-4 wow zoomIn" data-wow-delay="0.6s">
                    <div className="bg-primary shadow d-flex align-items-center justify-content-center p-4" style={{height:150}}>
                        <div className="bg-white d-flex align-items-center justify-content-center rounded mb-2" style={{width:60,height:60}}>
                            <i className="bi bi-check text-primary fs-2"></i>
                        </div>
                        <div className="ps-4">
                            <h5 className="text-white mb-0">Completed Projects</h5>
                            <h1 className="text-white mb-0" data-toggle="counter-up">5</h1>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div className="container-fluid py-5 wow fadeInUp" data-wow-delay="0.1s">
        <div className="container py-5">
            <div className="row g-5">
                <div className="col-lg-7">
                    <div className="section-title position-relative pb-3 mb-5">
                        <h5 className="fw-bold text-primary text-uppercase">About Us</h5>
                        <h1 className="mb-0">A leading Lebanese NGO in water, environment, and sustainable development.</h1>
                    </div>
                    <p className="mb-4">The Lebanese Center for Water and Environment (LCWE) is a certified non-profit organization committed to promoting sustainable water and environmental solutions across Lebanon. Through research, consultancy, and capacity-building, our expert team supports both public and private sectors in tackling climate, agricultural, and socio-economic challenges.</p>
                    <Link to='/about' className="btn btn-primary py-3 px-5 mt-3 wow zoomIn" data-wow-delay="0.9s">Read More</Link>
                </div>
                <div className="col-lg-5" style={{minHeight:500}}>
                    <div className="position-relative h-100">
                        <img className="position-absolute w-100 h-100 rounded wow zoomIn" data-wow-delay="0.9s" src={About} style={{objectFit:'cover'}} />
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div className="container-fluid py-5 wow fadeInUp" data-wow-delay="0.1s">
        <div className="container py-5">
            <div className="section-title text-center position-relative pb-3 mb-5 mx-auto" style={{maxWidth:600}}>
                <h5 className="fw-bold text-primary text-uppercase">Announcements</h5>
                <h1 className="mb-0">Latest LCWE News</h1>
            </div>
            <Slider {...settings}>
            {announcements.map((item) => ( 
                <Link to={`/content/${item.public_id}`} className="text-decoration-none text-reset">
                <div className="blog-item rounded overflow-hidden" key={item.public_id}> 
                    <div className="blog-img position-relative overflow-hidden"> 
                        <img className="img-fluid" src={`http://localhost:5000/uploads/images/${item.image}`} alt={item.type} /> 
                        <span className="position-absolute top-0 start-0 bg-primary text-white rounded-end mt-5 py-2 px-4"> {item.type.charAt(0).toUpperCase() + item.type.slice(1)} </span> 
                    </div> 
                    <div className="p-4"> 
                        <div className="d-flex mb-3"> 
                            <small> <i className="bi bi-calendar-event text-primary me-2"></i> {item.date &&
                      new Date(item.date).toLocaleDateString()} </small> 
                        </div> 
                        <h4 className="mb-2">{item.title}</h4>
                    </div> 
                </div> 
                </Link>
            ))}
            </Slider> 
        </div>
    </div>

    <div className="container-fluid py-5 wow fadeInUp" data-wow-delay="0.1s">
        <div className="container py-5">
            <div className="section-title text-center position-relative pb-3 mb-5 mx-auto" style={{maxWidth:600}}>
                <h5 className="fw-bold text-primary text-uppercase">Explore Our Work</h5>
                <h1 className="mb-0">Discover our latest workshops, insights, publications, and training programs.</h1>
            </div>
            <div className="row g-3">
                <div className="col-lg-7 col-md-6">
                    <div className="row g-3">
                        <div className="col-lg-12 col-md-12 wow zoomIn" data-wow-delay="0.1s">
                            <a className="position-relative d-block overflow-hidden" href="">
                                <img className="img-fluid" src={img1} alt="" />
                                <div className="bg-white text-center position-absolute bottom-0 end-0 py-2 px-3" style={{margin:1}} >
                                    <h5 className="m-0">Workshops</h5>
                                    <small className="text-primary">6 Workshops</small>
                                </div>
                            </a>
                        </div>
                        <div className="col-lg-6 col-md-12 wow zoomIn" data-wow-delay="0.3s">
                            <a className="position-relative d-block overflow-hidden" href="">
                                <img className="img-fluid" src={img2} alt="" />
                                <div className="bg-white text-center position-absolute bottom-0 end-0 py-2 px-3" style={{margin:1}}>
                                    <h5 className="m-0">Reports</h5>
                                    <small className="text-primary">8 Reports</small>
                                </div>
                            </a>
                        </div>
                        <div className="col-lg-6 col-md-12 wow zoomIn" data-wow-delay="0.5s">
                            <a className="position-relative d-block overflow-hidden" href="">
                                <img className="img-fluid" src={img3} alt="" />
                                <div className="bg-white text-center position-absolute bottom-0 end-0 py-2 px-3" style={{margin:1}}>
                                    <h5 className="m-0">Blogs</h5>
                                    <small className="text-primary">6 Blogs</small>
                                </div>
                            </a>
                        </div>
                    </div>
                </div>
                <div className="col-lg-5 col-md-6 wow zoomIn" data-wow-delay="0.7s" style={{minHeight:350}} >
                    <a className="position-relative d-block h-100 overflow-hidden" href="">
                        <img className="img-fluid position-absolute w-100 h-100" src={img4} alt="" style={{objectFit:'cover'}} />
                        <div className="bg-white text-center position-absolute bottom-0 end-0 py-2 px-3" style={{margin:1}}>
                            <h5 className="m-0">Training Courses</h5>
                            <small className="text-primary">6 Training Courses</small>
                        </div>
                    </a>
                </div>
            </div>
        </div>
    </div>

    <div className="container-fluid py-5 wow fadeInUp" data-wow-delay="0.1s">
        <div className="container py-5">
            <div className="section-title text-center position-relative pb-3 mb-5 mx-auto" style={{maxWidth:600}}>
                <h5 className="fw-bold text-primary text-uppercase">Latest Projects</h5>
                <h1 className="mb-0">A look at our latest efforts to protect resources and empower communities</h1>
            </div>
            <div className="row g-5">
                <div className="col-lg-4 col-md-6 wow zoomIn" data-wow-delay="0.3s">
                    <div className="service-item bg-light rounded d-flex flex-column align-items-center justify-content-center text-center">
                        <div className="service-icon">
                            <i className="bi bi-search text-white"></i>
                        </div>
                        <h4 className="mb-3">ABCDryBasin Project</h4>
                        <p className="m-0">Stakeholder Participation to Enhance Drought Resilience through Reinforced Indigenous Knowledge and Smart Tools for Socially-Just Water Management</p>
                        <a className="btn btn-lg btn-primary rounded" href="">
                            <i className="bi bi-arrow-right"></i>
                        </a>
                    </div>
                </div>
                <div className="col-lg-4 col-md-6 wow zoomIn" data-wow-delay="0.6s">
                    <div className="service-item bg-light rounded d-flex flex-column align-items-center justify-content-center text-center">
                        <div className="service-icon">
                            <i className="bi bi-check text-white"></i>
                        </div>
                        <h4 className="mb-3">RESMYLE Project</h4>
                        <p className="m-0">Empowering Youth for Sustainable Water Management in Kfarrouman</p>
                        <a className="btn btn-lg btn-primary rounded" href="">
                            <i className="bi bi-arrow-right"></i>
                        </a>
                    </div>
                </div>
                <div className="col-lg-4 col-md-6 wow zoomIn" data-wow-delay="0.9s">
                    <div className="service-item bg-light rounded d-flex flex-column align-items-center justify-content-center text-center">
                        <div className="service-icon">
                            <i className="bi bi-check text-white"></i>
                        </div>
                        <h4 className="mb-3">Co-Evolve4BG Project</h4>
                        <p className="m-0">Co-evolution of coastal human activities & Med natural systems for sustainable tourism & Blue Growth in the Mediterranean</p>
                        <a className="btn btn-lg btn-primary rounded" href="">
                            <i className="bi bi-arrow-right"></i>
                        </a>
                    </div>
                </div>
                <div className="col-lg-4 col-md-6 wow zoomIn" data-wow-delay="0.3s">
                    <div className="service-item bg-light rounded d-flex flex-column align-items-center justify-content-center text-center">
                        <div className="service-icon">
                            <i className="bi bi-check text-white"></i>
                        </div>
                        <h4 className="mb-3">Project</h4>
                        <p className="m-0">Optimal water abstraction infrastructure in the Yarmouk River Basin</p>
                        <a className="btn btn-lg btn-primary rounded" href="">
                            <i className="bi bi-arrow-right"></i>
                        </a>
                    </div>
                </div>
                <div className="col-lg-4 col-md-6 wow zoomIn" data-wow-delay="0.6s">
                    <div className="service-item bg-light rounded d-flex flex-column align-items-center justify-content-center text-center">
                        <div className="service-icon">
                            <i className="bi bi-check text-white"></i>
                        </div>
                        <h4 className="mb-3">WIN-II</h4>
                        <p className="m-0">Water Intelligence Near East: Advances in new data and tools to support water management in the Litani River Basin</p>
                        <a className="btn btn-lg btn-primary rounded" href="">
                            <i className="bi bi-arrow-right"></i>
                        </a>
                    </div>
                </div>
                <div className="col-lg-4 col-md-6 wow zoomIn" data-wow-delay="0.9s">
                    <a href="#">
                        <div className="position-relative bg-primary rounded h-100 d-flex flex-column align-items-center justify-content-center text-center p-5">
                            <h3 className="text-white mb-3">Discover More Projects!</h3>
                        </div>
                    </a>
                </div>
            </div>
        </div>
    </div>

    <div className="container-fluid py-5 wow fadeInUp" data-wow-delay="0.1s">
        <div className="container py-5">
            <div className="section-title text-center position-relative pb-3 mb-4 mx-auto" style={{maxWidth:600}}>
                <h5 className="fw-bold text-primary text-uppercase">Upcoming Events</h5>
                <h1 className="mb-0">Stay informed and register for our upcoming events</h1>
            </div>
            <div className="row" id="tabs">
              <div className="col-lg-4">
          <ul>
            <li>
              <a><button className="btn" onClick={() => setActiveTab('tab1')} style={{color:'white',fontSize:'bold'}}>
                Workshop: Soil Contamination and Phytoremediation
              </button></a>
            </li>
            <li>
              <a><button className="btn" onClick={() => setActiveTab('tab2')} style={{color:'white',fontSize:'bold'}}>
                Training Course: Smart Water, Smarter Tech: The GIS Revolution
              </button></a>
            </li>
            <li>
              <a><button className="btn" onClick={() => setActiveTab('tab3')} style={{color:'white',fontSize:'bold'}}>
                Symposium: The Historical Evolution of Water Management
              </button></a>
            </li>
            <div className="main-rounded-button">
              <Link to="/detail">View All Schedules</Link>
            </div>
          </ul>
        </div>

        <div className="col-lg-8">
          {activeTab === 'tab1' && (
            <div>
              <h4>Workshop: Soil Contamination and Phytoremediation</h4>
              <p>
                <strong>Date: </strong>AUG 26, 2025
                <br />
                <strong>Time: </strong>11:00 AM - 12:00 PM
              </p>
              <div className="main-button">
                <a href="#">Register Now!</a>
              </div>
            </div>
          )}
          {activeTab === 'tab2' && (
            <div>
              <h4>Training Course: Smart Water, Smarter Tech: The GIS Revolution</h4>
              <p>
                <strong>Date: </strong>AUG 26, 2025
                <br />
                <strong>Time: </strong>11:00 AM - 12:00 PM
              </p>
              <div className="main-button">
                <a href="#">Register Now!</a>
              </div>
            </div>
          )}
          {activeTab === 'tab3' && (
            <div>
              <h4>Symposium: The Historical Evolution of Water Management</h4>
              <p>
                <strong>Date: </strong>AUG 26, 2025
                <br />
                <strong>Time: </strong>11:00 AM - 12:00 PM
              </p>
              <div className="main-button">
                <a href="#">Register Now!</a>
              </div>
            </div>
          )}
        </div>
            </div>
        </div>
    </div>

    <div className="container-fluid py-5 wow fadeInUp" data-wow-delay="0.1s">
        <div className="container py-5 mb-5">
            <div className="section-title text-center position-relative pb-3 mb-5 mx-auto" style={{maxWidth:600}} >
                <h5 className="fw-bold text-primary text-uppercase">Our Partners</h5>
                <h1 className="mb-0">Together for a sustainable future</h1>
            </div>
            <div className="bg-white">
                <Slider {...logos}>
                  {partnersImages.map((src, index) => (
                    <img key={index} src={src} alt={`Partner ${index + 1}`} />
                  ))}
                </Slider>
            </div>
        </div>
    </div>

    </>
  );
};

export default Home;
