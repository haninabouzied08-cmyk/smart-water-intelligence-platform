import 'bootstrap/dist/css/bootstrap.min.css';
import 'bootstrap/dist/js/bootstrap.bundle.min';
import 'bootstrap-icons/font/bootstrap-icons.css';
import React from "react";
import { BrowserRouter as Router, Routes, Route, Link, useParams, useNavigate } from 'react-router-dom';
import Spinner from "../components/Spinner";
import BackToTop from "../components/BackToTop";
import Navbar from "../components/Navbar";
import Footer from "../components/Footer";
import Topbar from "../components/Topbar";
import "../index.css";
import { Helmet } from 'react-helmet';
import { useState } from "react"; import axios from "axios";

const Contact = () => {
    const [form, setForm] = useState({ name: "", email: "", subject: "", message: "" }); 
    const handleChange = (e) => { 
        setForm({ ...form, [e.target.name]: e.target.value }); 
    }; 
    const handleSubmit = async (e) => { 
        e.preventDefault(); 
        try { 
            await axios.post("http://localhost:5000/api/contact", form); 
            alert("Message sent successfully!"); 
            setForm({ name: "", email: "", subject: "", message: "" }); 
        } catch (err) { 
            alert("Failed to send message"); 
        } 
    };
    
    return (
    <>
       <Helmet>
        <title>LCWE | Contact Us</title>
      </Helmet>
      <div className="container-fluid position-relative p-0">
        <Navbar />
        <div className="container-fluid bg-primary py-5 bg-header" style={{marginBottom:90}}>
            <div className="row py-5">
                <div className="col-12 pt-lg-5 mt-lg-5 text-center">
                    <h1 className="display-4 text-white animated zoomIn">Contact Us</h1>
                    <Link to="/" className="h5 text-white">Home</Link>
                    <i className="bi bi-circle text-white px-2"></i>
                    <Link to='/contact' className="h5 text-white">Contact</Link>
                </div>
            </div>
        </div>
      </div>

      <div className="container-fluid wow fadeInUp" data-wow-delay="0.1s">
        <div className="container">
            <div className="section-title text-center position-relative pb-3 mb-5 mx-auto" style={{maxWidth:600}}>
                <h5 className="fw-bold text-primary text-uppercase">Contact Us</h5>
                <h1 className="mb-0">If You Have Any Query, Feel Free To Contact Us</h1>
            </div>
            <div className="row g-5 mb-5">
                <div className="col-lg-6">
                    <div className="d-flex align-items-center wow fadeIn" data-wow-delay="0.4s">
                        <div className="bg-primary d-flex align-items-center justify-content-center rounded" style={{width:60,height:60}}>
                            <i className="bi bi-envelope-open text-white"></i>
                        </div>
                        <div className="ps-4">
                            <h5 className="mb-2">Email to get free quote</h5>
                            <h4 className="text-primary mb-0">lcwe.officiallb@gmail.com</h4>
                        </div>
                    </div>
                </div>
                <div className="col-lg-6">
                    <div className="d-flex align-items-center wow bideIn" data-wow-delay="0.8s">
                        <div className="bg-primary d-flex align-items-center justify-content-center rounded" style={{width:60,height:60}}>
                            <i className="bi bi-geo-alt text-white"></i>
                        </div>
                        <div className="ps-4">
                            <h5 className="mb-2">Visit our office</h5>
                            <h4 className="text-primary mb-0">Kfarjouz, Al-Nabatieh, Lebanon</h4>
                        </div>
                    </div>
                </div>
            </div>
            <div className="row g-5">
                <div className="col-lg-6 wow slideInUp" data-wow-delay="0.3s">
                    <form onSubmit={handleSubmit}>
                        <div className="row g-3">
                            <div className="col-md-6">
                                <input type="text"  name="name" value={form.name} onChange={handleChange} className="form-control border-0 bg-light px-4" placeholder="Your Name" style={{height:55}} />
                            </div>
                            <div className="col-md-6">
                                <input
                                  type="email"
                                  className="form-control border-0 bg-light px-4"
                                  value={form.email} onChange={handleChange}
                                  placeholder="Your Email"
                                  style={{ height:'55px' }}
                                />
                            </div>
                            <div className="col-12">
                                <input type="text" value={form.subject} onChange={handleChange} className="form-control border-0 bg-light px-4" placeholder="Subject" style={{height:55}} />
                            </div>
                            <div className="col-12">
                                <textarea className="form-control border-0 bg-light px-4 py-3" value={form.message} onChange={handleChange} rows="4" placeholder="Message"></textarea>
                            </div>
                            <div className="col-12">
                                <button className="btn btn-primary w-100 py-3" type="submit">Send Message</button>
                            </div>
                        </div>
                    </form>
                </div>
                <div className="col-lg-6 wow slideInUp" data-wow-delay="0.6s">
                    <iframe className="position-relative rounded w-100 h-100" 
                        src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3331.2263447182677!2d35.483229899999984!3d33.39125860000001!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x151eeb00262bc8a3%3A0x38f54ae95db2ee24!2z2KfZhNmF2LHZg9iyINin2YTZhNio2YbYp9mG2Yog2YTZhNmF2YrYp9mHINmI2KfZhNio2YrYptipIHwgTENXRQ!5e0!3m2!1sen!2slb!4v1755682683355!5m2!1sen!2slb" 
                        width="600" height="450" frameborder="0" style={{minHeight:350,border:0}} allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade" aria-hidden="false" tabindex="0">
                    </iframe>
                </div>
            </div>
        </div>
      </div>
    </>
  );
};

export default Contact;
