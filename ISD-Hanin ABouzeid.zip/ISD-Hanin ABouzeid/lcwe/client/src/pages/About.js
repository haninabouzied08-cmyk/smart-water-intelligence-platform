import React from "react";
import Spinner from "../components/Spinner";
import BackToTop from "../components/BackToTop";
import Navbar from "../components/Navbar";
import Footer from "../components/Footer";
import Topbar from "../components/Topbar";
import "../index.css";
import 'bootstrap/dist/css/bootstrap.min.css';
import 'bootstrap/dist/js/bootstrap.bundle.min';
import 'bootstrap-icons/font/bootstrap-icons.css';
import { Helmet } from 'react-helmet';

const About = () => {
  return (
    <>
    <Helmet>
        <title>LCWE | About LCWE</title>
      </Helmet>
      <div className="container-fluid position-relative p-0">
        <Navbar />
        <div className="container-fluid bg-primary py-5 bg-header" style={{marginBottom:90}}>
            <div className="row py-5">
                <div className="col-12 pt-lg-5 mt-lg-5 text-center">
                    <h1 className="display-4 text-white animated zoomIn">About Us</h1>
                    <a href="" className="h5 text-white">Home</a>
                    <i className="bi bi-circle text-white px-2"></i>
                    <a href="" className="h5 text-white">About</a>
                </div>
            </div>
        </div>
      </div>

      <div className="container-fluid py-3 wow fadeInUp" data-wow-delay="0.1s">
        <div className="container PY-0">
            <div className="section-title text-center position-relative pb-3 mb-5 mx-auto" style={{maxWidth:600}}>
                <h5 className="fw-bold text-primary text-uppercase">Welcome to</h5>
                <h1 className="mb-0">The Lebanese Center for Water and Environmnet</h1>
            </div>
            <div className="row g-5 justify-content-center align-items-center">
                <div className="col-lg-10 col-md-6 wow slideInUp">
                    <p className="mb-5" style={{textAlign:'justify'}}>
                        The Lebanese Center for Water and Environment (LCWE) is a pioneering non-governmental organization working at the intersection of science, policy, and community action. Founded with the belief that sustainable water and environmental management is essential for a thriving society, LCWE unites academics, experts, and young professionals to address Lebanon’s most urgent ecological challenges.
                        <br /><br />
                        We see ourselves not just as a center for research, but as a hub for innovation and collaboration, connecting local communities with national and international expertise to create long-term solutions.
                    </p>
                    <div className="row g-0 mb-3">
                        <div className="section-title section-title-sm position-relative pb-3 mb-4">
                            <h3 className="mb-0">Our Objectives</h3>
                        </div>
                        <div className="col-sm-12 wow zoomIn" data-wow-delay="0.2s">
                            <h6 className="mb-3" style={{textAlign:'justify'}}><i className="bi bi-check text-primary me-3"></i>Conduct cutting-edge scientific research that informs decision-making and policy reform.</h6>
                            <h6 className="mb-3" style={{textAlign:'justify'}}><i className="bi bi-check text-primary me-3"></i>Deliver training programs and workshops that build the capacity of students, professionals, and institutions.</h6>
                        </div>
                        <div className="col-sm-12 wow zoomIn" data-wow-delay="0.4s">
                            <h6 className="mb-3" style={{textAlign:'justify'}}><i className="bi bi-check text-primary me-3"></i>24/7 Encourage community engagement by raising awareness on water scarcity, pollution, and climate resilience.</h6>
                            <h6 className="mb-3" style={{textAlign:'justify'}}><i className="bi bi-check text-primary me-3"></i>Foster International collaboration, creating bridges between Lebanon and global networks of expertise.</h6>
                            <h6 className="mb-3" style={{textAlign:'justify'}}><i className="bi bi-check text-primary me-3"></i>Publish reports, policy papers, and educational resources that promote sustainable development.</h6>
                        </div>
                    </div>
                </div>
            </div>
            <div className="row g-5 justify-content-center align-items-center" data-wow-delay="0.6s">
                <div className=" d-flex col-lg-10 col-md-6 wow slideInUp">
                <div className="col-lg-6 testimonial-item shadow my-4 mx-4">
                    <div className="d-flex align-items-center border-bottom pt-5 pb-4 px-5">
                        <div className="ps-4">
                            <h4 className="text-primary mb-1">Mission</h4>
                        </div>
                    </div>
                    <div className="pt-4 pb-5 px-5">
                        We promote sustainable water and environmental practices through research, education, and practical solutions, empowering communities and decision-makers to adapt to climate change and protect natural resources.
                    </div>
                </div>
                <div className="col-lg-6 testimonial-item shadow my-4">
                    <div className="d-flex align-items-center border-bottom pt-5 pb-4 px-5">
                        <div className="ps-4">
                            <h4 className="text-primary mb-1">Vision</h4>
                        </div>
                    </div>
                    <div className="pt-4 pb-5 px-5">
                        We envision a resilient Lebanon and region where water and environmental resources are managed wisely, communities thrive in balance with nature, and future generations inherit a healthier, safer, and more sustainable world.
                    </div>
                </div>
                </div>
            </div>
        </div>
    </div>

    <div className="container-fluid py-5 wow fadeInUp bg-light" data-wow-delay="0.1s">
        <div className="container py-5">
            <div className="col-lg-10 col-md-6">
                <div className="col-lg-12 section-title text-align position-relative pb-3 mb-5 mx-auto" style={{maxWidth:800}}>
                    <h5 className="fw-bold text-primary text-uppercase">What We Do</h5>
                    <h3 className="mb-0">Our team of experts offers a wide range of multi-disciplinary studies and consultancies, tailored to meet the needs of both the private and public sectors.</h3>
                </div>
            </div>
            <div className="row g-5 justify-content-center align-items-center">
                <div className="col-lg-10 col-md-6 wow slideInUp">
                <div className="col-lg-12 mx-4">
                    <div className="row g-5">
                        <div className="col-12 wow zoomIn shadow" data-wow-delay="0.2s">
                            <div className="bg-primary rounded d-flex align-items-center justify-content-center mb-3" style={{width:60,height:60}}>
                                <i className="bi bi-check text-white"></i>
                            </div>
                            <h4>Water Resource Management</h4>
                            <ul>
                                <li>Executing studies and consultancies on surface and groundwater resources assessment.</li>
                                <li>Studying and locating groundwater potential sites, including well logging and hydro-stratigraphic characterization.</li>
                                <li>Identifying suitable locations for surface water harvesting based on detailed hydrological assessments.</li>
                            </ul>
                        </div>
                        <div className="col-12 wow zoomIn shadow" data-wow-delay="0.6s">
                            <div className="bg-primary rounded d-flex align-items-center justify-content-center mb-3" style={{width:60, height:60}}>
                                <i className="bi bi-check text-white"></i>
                            </div>
                            <h4>Environmental Assessment</h4>
                            <ul>
                                <li>Assessing environmental flow conditions and stream flow sustainability for rivers and springs.</li>
                                <li>Conducting Environmental Impact Assessments (EIA) to identify environmental impacts of projects and propose mitigation measures.</li>
                                <li>Identifying suitable locations for Natural Reserves and assessing existing protected areas.</li>
                            </ul>
                        </div>
                        <div className="col-12 wow zoomIn shadow" data-wow-delay="0.4s">
                            <div className="bg-primary rounded d-flex align-items-center justify-content-center mb-3" style={{width:60, height:60}}>
                                <i className="bi bi-check text-white"></i>
                            </div>
                            <h4>Geological and Geospatial Studies</h4>
                            <ul>
                                <li>Conducting geological studies with a focus on economic geology.</li>
                                <li>Using remote sensing and GIS for land cover/use monitoring, change detection, and more.</li>
                                <li>Applying Digital Elevation Models (DEMs) for terrain analysis and water flow regime studies.</li>
                            </ul>
                        </div>
                        <div className="col-12 wow zoomIn shadow" data-wow-delay="0.8s">
                            <div className="bg-primary rounded d-flex align-items-center justify-content-center mb-3" style={{width:60, height:60}}>
                                <i className="bi bi-check text-white"></i>
                            </div>
                            <h4>Agriculture and Food Safety</h4>
                            <ul>
                                <li>Studying soil characteristics and mapping for agriculture and construction applications.</li>
                                <li>Performing agricultural demonstrations and training for farmers.</li>
                                <li>Analyzing food safety and purity in food products and adopting quality programs like ISO 22000.</li>
                            </ul>
                        </div>
                        <div className="col-12 wow zoomIn shadow" data-wow-delay="0.4s">
                            <div className="bg-primary rounded d-flex align-items-center justify-content-center mb-3" style={{width:60,height:60}}>
                                <i className="bi bi-check text-white"></i>
                            </div>
                            <h4>Climate and Risk Assessment</h4>
                            <ul>
                                <li>Applying climatic models to study the impact of climate change on water, agriculture, and energy sectors.</li>
                                <li>Conducting Vulnerability Assessments for areas at risk from natural and man-made hazards, such as floods and landslides.</li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
            </div>
        </div>
    </div>

    <div className="container-fluid py-5 wow fadeInUp" data-wow-delay="0.1s">
        <div className="container py-5 mb-5">
            <div className="row g-5 justify-content-center align-items-center">
                <div className="col-lg-10 col-md-6 wow slideInUp">
                    <div className="row g-0 mb-3">
                        <div className="section-title section-title-sm position-relative pb-3 mb-4">
                            <h3 className="mb-0">Our Expertise</h3>
                        </div>
                        <div className="col-sm-12 wow zoomIn" data-wow-delay="0.2s">
                            <p className="mb-3">
                                At LCWE, our strength lies in a multidisciplinary team with advanced degrees across water resources, engineering, environmental sciences, computer science, law, and social sciences. This diversity enables us to deliver integrated solutions that bridge science, technology, and communities.
                            </p>
                        </div>
                        <div className="col-sm-12 wow zoomIn" data-wow-delay="0.4s">
                            <h6 className="mb-3" style={{textAlign:'justify'}}><i className="bi bi-check text-primary me-3"></i>24/7 Encourage community engagement by raising awareness on water scarcity, pollution, and climate resilience.</h6>
                            <h6 className="mb-3" style={{textAlign:'justify'}}><i className="bi bi-check text-primary me-3"></i>Foster International collaboration, creating bridges between Lebanon and global networks of expertise.</h6>
                            <h6 className="mb-3" style={{textAlign:'justify'}}><i className="bi bi-check text-primary me-3"></i>Publish reports, policy papers, and educational resources that promote sustainable development.</h6>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    </>
  );
};

export default About;
