import React, { useState } from "react";
import axios from "axios";
import { useNavigate, Navigate } from "react-router-dom";
import login from '../assets/img/login.jpeg';
import Navbar from "../components/Navbar";
import { Helmet } from 'react-helmet';

function Login() {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [loading, setLoading] = useState(false);
  const navigate = useNavigate();

  const token = localStorage.getItem("token");
  if (token) {
    return <Navigate to="/swip" replace />;
  }

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);

    try {
      // --------------------- LOGIN ---------------------
      let res = await axios.post("http://localhost:5000/api/auth/login", {
        email,
        password,
      });

      // Login successful → store token
      localStorage.setItem("token", res.data.token);
      navigate("/swip");
    } catch (loginErr) {
      // If login fails with 401 (user not found or wrong password), try signup
      if (loginErr.response && loginErr.response.status === 401) {
        try {
          let res = await axios.post("http://localhost:5000/api/auth/signup", {
            email,
            password,
          });

          // Signup successful → store token
          localStorage.setItem("token", res.data.token);
          navigate("/swip");
        } catch (signupErr) {
          console.error("Signup error:", signupErr);
          alert(
            signupErr.response?.data?.message || "Signup failed. Please try again."
          );
        }
      } else {
        console.error("Login error:", loginErr);
        alert(
          loginErr.response?.data?.message || "Authentication failed. Please try again."
        );
      }
    } finally {
      setLoading(false);
    }
  };

  return (
    <>
    <Helmet>
        <title>LCWE | Login</title>
      </Helmet>
      <div className="container-fluid position-relative p-0">
        <Navbar />
      </div>
  <section className="p-3 p-md-4 p-xl-5">
    <div className="container">
      <div className="card border-light-subtle shadow-sm">
        <div className="row g-0">
          <div className="col-12 col-md-6">
            <img className="img-fluid rounded-start w-100 h-100 object-fit-cover" loading="lazy" src={login} alt="BootstrapBrain Logo" />
          </div>
          <div className="col-12 col-md-6">
            <div className="card-body p-3 p-md-4 p-xl-5">
              <div className="row">
                <div className="col-12">
                  <div className="mb-5">
                    <h3>Sign In / Sign Up</h3>
                  </div>
                </div>
              </div>
              <form onSubmit={handleSubmit}>
                <div className="row gy-3 gy-md-4 overflow-hidden">
                  <div className="col-12">
                    <label for="email" className="form-label">Email <span className="text-danger">*</span></label>
                    <input type="email" value={email} className="form-control" name="email" id="email" placeholder="name@example.com" onChange={(e) => setEmail(e.target.value)} required />
                  </div>
                  <div className="col-12">
                    <label for="password" className="form-label">Password <span className="text-danger">*</span></label>
                    <input type="password" className="form-control" name="password" id="password" value={password} onChange={(e) => setPassword(e.target.value)} required />
                  </div>
                  {/* <div className="col-12">
                    <div className="form-check">
                      <input className="form-check-input" type="checkbox" value="" name="remember_me" id="remember_me">
                      <label className="form-check-label text-secondary" for="remember_me">
                        Keep me logged in
                      </label>
                    </div>
                  </div> */}
                  <div className="col-12">
                    <div className="d-grid">
                      <button className="btn bsb-btn-xl btn-primary" type="submit"  disabled={loading}>{loading ? "Processing..." : "Continue"}</button>
                    </div>
                  </div>
                </div>
              </form>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>
    </>
  );
}

export default Login;
