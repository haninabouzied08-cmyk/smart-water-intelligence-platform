import { useEffect, useState } from "react";
import { useParams } from "react-router-dom";
import { getContentByPublicId } from "../api/publicContent.api";
import Navbar from "../components/Navbar";
import { Accordion } from "react-bootstrap";

export default function ProjectDetails() {
  const { publicId } = useParams();
  const [project, setProject] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");

  useEffect(() => {
    let mounted = true;

    const load = async () => {
      try {
        setLoading(true);
        const data = await getContentByPublicId(publicId);
        if (mounted) setProject(data);
      } catch (err) {
        console.error(err);
        setError("Project not found.");
      } finally {
        if (mounted) setLoading(false);
      }
    };

    load();
    return () => (mounted = false);
  }, [publicId]);

  if (loading) return <p>Loading...</p>;
  if (error) return <p style={{ color: "red" }}>{error}</p>;
  if (!project) return null;

  // Split objectives and activities into arrays
  const objectives = project.details?.objective
    ? project.details.objective.split("/").map((o) => o.trim()).filter(Boolean)
    : [];

  const activities = project.details?.activity
    ? project.details.activity.split("/").map((a) => a.trim()).filter(Boolean)
    : [];

  return (
    <>
      <div className="container-fluid position-relative p-0">
        <Navbar />
      </div>

      <div className="container py-5">
        <Accordion defaultActiveKey="0" id="projectsAccordion">
          <Accordion.Item eventKey="0" className="border-0">
            <Accordion.Header>
              <div className="d-flex justify-content-between w-100 project-box">
                <span>
                  <h3>{project.details?.acronym}</h3>
                  <b>Title: </b> {project.title}
                </span>
                <span>▼</span>
              </div>
            </Accordion.Header>

            <Accordion.Body>
              <div className="project-desc">
                <b>Duration: </b> {project.details?.end_date} <br />
                <b>Focus Region: </b> {project.details?.location} <br />
                <b>Partners: </b> {project.details?.partner} <br />
                <b>Funding: </b> {project.details?.funding} <br />
                <b>Goal: </b> {project.details?.goal} <br />

                {objectives.length > 0 && (
                  <>
                    <p><strong>Objective: </strong></p>
                    <ul>
                      {objectives.map((objective, idx) => (
                        <li key={idx}>{objective}</li>
                      ))}
                    </ul>
                  </>
                )}

                {activities.length > 0 && (
                  <>
                    <p><strong>Key Activities: </strong></p>
                    <ul>
                      {activities.map((activity, idx) => (
                        <li key={idx}>{activity}</li>
                      ))}
                    </ul>
                  </>
                )}
              </div>
            </Accordion.Body>
          </Accordion.Item>
        </Accordion>
      </div>
    </>
  );
}
