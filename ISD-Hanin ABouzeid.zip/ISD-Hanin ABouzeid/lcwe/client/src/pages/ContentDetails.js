import { useEffect, useState } from "react";
import { useParams } from "react-router-dom";
import { getContentByPublicId } from "../api/publicContent.api";
import SEO from "../components/SEO";
import "../index.css";
import 'bootstrap/dist/css/bootstrap.min.css';
import 'bootstrap/dist/js/bootstrap.bundle.min';
import 'bootstrap-icons/font/bootstrap-icons.css';
import { Helmet } from 'react-helmet';
import DetailsRenderer from './DetailsRenderer';
import SessionLinks from "../components/SessionLinks";
import Navbar from "../components/Navbar";

export default function ContentDetails() {
  const { publicId } = useParams();

  const [content, setContent] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");

  useEffect(() => {
    let mounted = true;

    const load = async () => {
      try {
        setLoading(true);
        const data = await getContentByPublicId(publicId);
        if (mounted) setContent(data);
      } catch (err) {
        console.error(err);
        setError("Content not found.");
      } finally {
        if (mounted) setLoading(false);
      }
    };

    load();
    return () => (mounted = false);
  }, [publicId]);

  if (loading) return <p>Loading...</p>;
  if (error) return <p style={{ color: "red" }}>{error}</p>;
  if (!content) return null;

  const { title, date, descr, image, type, details, sessions } = content;

  return (
    <>
    <div className="container-fluid position-relative p-0">
      <Navbar />
    </div>
    <SEO
      title={`${content.title} | LCWE`}
      description={content.descr?.slice(0, 160)}
      image={
        content.image
          ? `http://localhost:5000/uploads/images/${content.image}`
          : null
      }
      url={`https://yourdomain.com/content/${content.public_id}`}
      structuredData={{
        "@context": "https://schema.org",
        "@type": "Article",
        headline: content.title,
        description: content.descr,
        datePublished: content.date,
        image: content.image
          ? `http://localhost:5000/uploads/images/${content.image}`
          : undefined,
        author: {
          "@type": "Organization",
          name: "LCWE"
        }
      }}
    />

    <div className="container-fluid py-5 wow fadeInUp" data-wow-delay="0.1s">
      <div className="container py-5">
        <div className="row g-5">
          <div className="col-lg-8">
            <div className="mb-5">
              <div className="row g-5">
                <div className="col-lg-4">
                  {image && (
                    <img
                      src={`http://localhost:5000/uploads/images/${image}`}
                      alt={title}
                      className="img-fluid w-100 rounded mb-5"
                    />
                  )}
                </div>
                <div className="col-lg-8">
                  <h2 className="mb-4">{title}</h2>
                  <small>
                    <i className="bi bi-calendar-alt text-primary me-2"></i>
                    <b>{type} Date:</b>
                    {date && (
                      <p className="date">
                        {new Date(date).toLocaleDateString()}
                      </p>
                    )}
                  </small>
                  <p style={{textAlign: 'justify'}}>{descr}</p>
                  <DetailsRenderer type={type} details={details} />
                  
                  {type === "training" && Array.isArray(sessions) && sessions.length > 0 && (
                    <div className="mb-5">
                      <h2>Sessions:</h2>
                      {sessions.map((s) => (
                        <div key={s.id} className="mb-4 p-3 border rounded">
                          <h6>{s.title}</h6>
                          {s.date && (
                            <p><strong>Date: </strong>{new Date(s.date).toLocaleDateString()}</p>
                          )}
                          {s.trainer && <p><strong>Trainer: </strong> {s.trainer}</p>}
                          {s.link && <SessionLinks link={s.link} />}
                          {s.descr && <p><strong>Materials:</strong><br />{s.descr} </p> }
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              </div>
              {type === "training" && (
                <div className="col-lg-4">
                  <div className="wow slideInUp" data-wow-delay="0.1s">
                    <div className="section-title section-title-sm position-relative pb-3 mb-4">
                      <h3 className="mb-0">Details</h3>
                    </div>
                    <div className="bg-light text-center" style={{padding:30}}>
                      <p><strong>{date}</strong></p>
                      <hr/>
                      <p><strong>Language: </strong>{details?.language}</p>
                      <hr/>
                      <p><strong>Training Type: </strong>{details?.training_type}</p>
                      <hr/>
                    </div>
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
    </>
  );
}
