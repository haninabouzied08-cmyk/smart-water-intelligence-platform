from datetime import datetime
import pandas as pd
from db_utils import get_db_connection

FIELD_CAPACITY = {
    "sand": 0.15,
    "loam": 0.28,
    "clay": 0.40
}

def get_latest_weather():
    conn = get_db_connection()
    cursor = conn.cursor(dictionary=True)

    cursor.execute("""
        SELECT * FROM weather_snapshot
        ORDER BY created_at DESC
        LIMIT 1
    """)

    row = cursor.fetchone()
    cursor.close()
    conn.close()
    return row


def get_latest_requests():
    conn = get_db_connection()
    cursor = conn.cursor(dictionary=True)

    cursor.execute("""
        SELECT *
        FROM swip_requests
        WHERE (user_id, created_at) IN (
            SELECT user_id, MAX(created_at)
            FROM swip_requests
            GROUP BY user_id
        )
    """)

    rows = cursor.fetchall()
    cursor.close()
    conn.close()
    return rows


def calculate_irrigation(weather, request):
    soil_fc = FIELD_CAPACITY[request["soil_type"]]
    soil_moisture = weather["soil_moisture"] / 100

    root_depth = 0.6  # example
    ET0 = weather["solar_radiation"] * 0.01
    kc = 0.9

    ETc = ET0 * kc
    soil_deficit = (soil_fc - soil_moisture) * root_depth * 1000
    irrigation_mm = max(ETc - weather["rainfall"] + soil_deficit, 0)

    return irrigation_mm * request["area_m2"]


def save_irrigation(user_id, swip_id, liters):
    conn = get_db_connection()
    cursor = conn.cursor()

    cursor.execute("""
        INSERT INTO irrigation_history
        (user_id, swip_request_id, irrigation_date, irrigation_liters)
        VALUES (%s,%s,%s,%s)
    """, (user_id, swip_id, datetime.now(), liters))

    conn.commit()
    cursor.close()
    conn.close()


if __name__ == "__main__":
    weather = get_latest_weather()
    requests = get_latest_requests()

    for r in requests:
        liters = calculate_irrigation(weather, r)
        save_irrigation(r["user_id"], r["id"], liters)

    print("✅ Daily irrigation calculated")
