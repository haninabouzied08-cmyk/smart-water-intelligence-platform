import logo from './logo.svg';
import './App.css';
import { BrowserRouter, Routes, Route } from "react-router-dom";
import AdminRoutes from "./routes/AdminRoutes";
import ProtectedRoute from "./routes/ProtectedRoute";
import Login from "./pages/Login";
import ContentList from "./pages/ContentList";
import AddContent from "./pages/AddContent";
import EditContent from "./pages/EditContent";

function App() {
  return (
    <BrowserRouter>
      <Routes>
        <Route path="/login" element={<Login />} />

        <Route
          path="/contents"
          element={
            <ProtectedRoute>
              <ContentList />
            </ProtectedRoute>
          }
        />

        <Route
          path="/addContent"
          element={
            <ProtectedRoute>
              <AddContent />
            </ProtectedRoute>
          }
        />

        <Route
          path="/contents/edit/:id"
          element={
            <ProtectedRoute>
              <EditContent />
            </ProtectedRoute>
          }
        />

      </Routes>
    </BrowserRouter>
  );
}

export default App;
