import { Routes, Route } from "react-router-dom";
import AddContent from "../pages/AddContent";
import EditContent from "../pages/EditContent";
import ContentList from "../pages/ContentList";

export default function AdminRoutes() {
  return (
    <Routes>
      <Route path="/contents/new" element={<AddContent />} />
      <Route path="/contents/edit/:id" element={<EditContent />} />
      <Route path="/contents" element={<ContentList />} />
    </Routes>
  );
}
