import { useEffect, useState } from "react";
import { useParams } from "react-router-dom";
import { getContentById, updateContent } from "../api/contents.api";
import { uploadImage, uploadPdf } from "../api/upload.api";

const CONTENT_TYPES = {
  blog: {
    label: "blog",
    fields: ["link"]
  },
  workshop: {
    label: "workshop",
    fields: ["pdf_file"]
  },
  event: {
    label: "event",
    fields: ["pdf_file"]
  },
  training: {
    label: "training",
    fields: ["training_type", "language", "format", "training_objective"]
  },
  report: {
    label: "report",
    fields: ["pdf_file"]
  },
  publication: {
    label: "publication",
    fields: ["citation", "doi", "keyword"]
  },
  project: {
    label: "project",
    fields: ["acronym", "end_date", "funding", "location", "partner", "objective", "goal", "activity"]
  }
};

export default function EditContent() {
  const { id } = useParams();
  const [type, setType] = useState("");
  const [form, setForm] = useState({});
  const [sessions, setSessions] = useState([]);
  const [imageFile, setImageFile] = useState(null);
  const [pdfFile, setPdfFile] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    getContentById(id).then((data) => {
      setType(data.type);
      setForm({
        // base
        title: data.title || "",
        date: data.date || "",
        descr: data.descr || "",
        image:
        data.image ||
        data.base?.image ||
        data.details?.image ||
        "",

        // details
        link: data.details?.link || "",
        acronym: data.details?.acronym || "",
        end_date: data.details?.end_date || "",
        funding: data.details?.funding || "",
        location: data.details?.location || "",
        partner: data.details?.partner || "",
        objective: data.details?.objective || "",
        goal: data.details?.goal || "",
        activity: data.details?.activity || "",
        citation: data.details?.citation || "",
        doi: data.details?.doi || "",
        keyword: data.details?.keyword || "",
        training_type: data.details?.training_type || "",
        language: data.details?.language || "",
        format: data.details?.format || "",
        training_objective: data.details?.training_objective || "",
        pdf_file: data.details?.report || ""
      });
      if (data.type === "training") {
        setSessions(
        (data.sessions || []).map(s => ({
          title: s.title || "",
          date: s.date || "",
          link: s.link || "",
          trainer: s.trainer || "",
          descr: s.descr || ""
        }))
      );

      }
      setLoading(false);
    });
  }, [id]);

  const handleChange = (e) => {
    setForm({ ...form, [e.target.name]: e.target.value });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    try {
      let imageName = form.image;
      let pdfName = form.pdf_file;

      if (imageFile) {
        imageName = await uploadImage(imageFile);
      }

      if (pdfFile) {
        pdfName = await uploadPdf(pdfFile);
      }

      await updateContent(id, {
        type,
        base: {
          title: form.title,
          date: form.date,
          descr: form.descr,
          image: imageName
        },
        details: {
    // blog
        link: form.link ?? null,

        // project
        acronym: form.acronym ?? null,
        end_date: form.end_date ?? null,
        funding: form.funding ?? null,
        location: form.location ?? null,
        partner: form.partner ?? null,
        objective: form.objective ?? null,
        goal: form.goal ?? null,
        activity: form.activity ?? null,

        // publication
        citation: form.citation ?? null,
        doi: form.doi ?? null,
        keyword: form.keyword ?? null,

        // training
        training_type: form.training_type ?? null,
        language: form.language ?? null,
        format: form.format ?? null,
        training_objective: form.training_objective ?? null,

        // ✅ PDF (event / workshop / report)
        report: pdfName ?? null
        },
        sessions: sessions.map(s => ({
        title: s.title,
        date: s.date,
        link: s.link,
        trainer: s.trainer,
        descr: s.descr
        }))
      });


      alert("Content updated successfully");
    } catch (err) {
      alert(err.response?.data?.message || "Error updating content");
    }
  };

  if (loading) return <p>Loading...</p>;

  const fields = CONTENT_TYPES[type]?.fields || [];

  return (
    <form onSubmit={handleSubmit}>
      <h2>Edit {CONTENT_TYPES[type]?.label}</h2>

      <input
        name="title"
        value={form.title}
        onChange={handleChange}
        required
      />

      <input
        type="date"
        name="date"
        value={form.date}
        onChange={handleChange}
      />

      <textarea
        name="descr"
        placeholder="Description"
        value={form.descr}
        onChange={handleChange}
      />

      {/* Replace image */}
      {form.image && (
        <div>
          <p>Current image:</p>
          <img
            src={`http://localhost:5000/uploads/${form.image}`}
            alt="Current"
            style={{ width: 150 }}
          />
        </div>
      )}

      <input
        type="file"
        accept="image/*"
        onChange={(e) => setImageFile(e.target.files[0])}
      />

      {fields.includes("link") && (
        <input
          type="link"
          name="link"
          placeholder="Link"
          value={form.link}
          onChange={handleChange}
        />
      )}

      {fields.includes("training_type") && (
        <input
          name="training_type"
          placeholder="Training Type"
          value={form.training_type}
          onChange={handleChange}
        />
      )}

      {fields.includes("language") && (
        <input
          name="language"
          placeholder="Language"
          value={form.language}
          onChange={handleChange}
        />
      )}

      {fields.includes("training_objective") && (
        <textarea
          name="training_objective"
          placeholder="Objective"
          value={form.training_objective}
          onChange={handleChange}
        />
      )}

      {fields.includes("format") && (
        <input
          name="format"
          placeholder="Format"
          value={form.format}
          onChange={handleChange}
        />
      )}

      {/* Project fields */}

      {fields.includes("acronym") && (
        <input
          name="acronym"
          placeholder="Acronym"
          value={form.acronym}
          onChange={handleChange}
        />
      )}

      {fields.includes("end_date") && (
        <input
          type="date"
          name="end_date"
          placeholder="End Date"
          value={form.end_date}
          onChange={handleChange}
        />
      )}

      {fields.includes("funding") && (
        <input
          name="funding"
          placeholder="Funding"
          value={form.funding}
          onChange={handleChange}
        />
      )}

      {fields.includes("location") && (
        <input
          name="location"
          placeholder="location"
          value={form.location}
          onChange={handleChange}
        />
      )}

      {fields.includes("partner") && (
        <input
          name="partner"
          placeholder="Partner"
          value={form.partner}
          onChange={handleChange}
        />
      )}

      {fields.includes("objective") && (
        <textarea
          name="objective"
          placeholder="Objective"
          value={form.objective}
          onChange={handleChange}
        />
      )}

      {fields.includes("goal") && (
        <textarea
          name="goal"
          placeholder="Goal"
          value={form.goal}
          onChange={handleChange}
        />
      )}

      {fields.includes("activity") && (
        <textarea
          name="activity"
          placeholder="Activity"
          value={form.activity}
          onChange={handleChange}
        />
      )}

      {fields.includes("citation") && (
        <textarea
          name="citation"
          placeholder="Citation"
          value={form.citation}
          onChange={handleChange}
        />
      )}

      {fields.includes("doi") && (
      <input
        type="link"
        name="doi"
        placeholder="Doi"
        value={form.doi}
        onChange={handleChange}
      />
      )}

      {fields.includes("keyword") && (
        <input
          name="keyword"
          placeholder="Keyword"
          value={form.keyword}
          onChange={handleChange}
        />
      )}

      {type === "training" && (
        <div>
          <h3>Training Sessions</h3>

          {sessions.map((s, index) => (
            <div key={index} style={{ border: "1px solid #ccc", padding: 10, marginBottom: 10 }}>
              <input
                placeholder="Session Title"
                value={s.title}
                onChange={(e) => {
                  const copy = [...sessions];
                  copy[index].title = e.target.value;
                  setSessions(copy);
                }}
              />

              <input
                type="date"
                value={s.date}
                onChange={(e) => {
                  const copy = [...sessions];
                  copy[index].date = e.target.value;
                  setSessions(copy);
                }}
              />

              <input
                placeholder="Session Link"
                value={s.link}
                onChange={(e) => {
                  const copy = [...sessions];
                  copy[index].link = e.target.value;
                  setSessions(copy);
                }}
              />

              <input
                placeholder="Trainer"
                value={s.trainer}
                onChange={(e) => {
                  const copy = [...sessions];
                  copy[index].trainer = e.target.value;
                  setSessions(copy);
                }}
              />

              <textarea
                placeholder="Description"
                value={s.descr}
                onChange={(e) => {
                  const copy = [...sessions];
                  copy[index].descr = e.target.value;
                  setSessions(copy);
                }}
              />

              <button
                type="button"
                onClick={() =>
                  setSessions(sessions.filter((_, i) => i !== index))
                }
              >
                Remove Session
              </button>
            </div>
          ))}

          <button
            type="button"
            onClick={() =>
              setSessions([...sessions, { title: "", date: "", link: "", trainer: "", descr: "" }])
            }
          >
            + Add Session
          </button>
        </div>
      )}



      {fields.includes("pdf_file") && (
        <input
          type="file"
          accept="application/pdf"
          onChange={(e) => setPdfFile(e.target.files[0])}
        />
      )}

      <button>Update</button>
    </form>
  );
}
