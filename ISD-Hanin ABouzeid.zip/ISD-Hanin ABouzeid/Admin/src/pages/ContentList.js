import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { getContents, deleteContent } from "../api/contents.api";
import { useNavigate, Navigate } from "react-router-dom";
import api from "../api/axios";

const CONTENT_TYPES = {
  "": "All",
  blog: "Blogs",
  workshop: "Workshops",
  publication: "Publications",
  project: "Projects",
  event: "Events & Webinars",
  training: "Training Courses",
  report: "Reports"
};

export default function ContentList() {
  const [contents, setContents] = useState([]);
  const [type, setType] = useState("");
  const [loading, setLoading] = useState(true);

  const loadData = async () => {
    setLoading(true);
    const data = await getContents(type);
    setContents(data);
    setLoading(false);
  };

  const navigate = useNavigate();

  useEffect(() => {
    loadData();
  }, [type]);

  const handleDelete = async (id) => {
    const confirm = window.confirm(
      "Are you sure you want to delete this content?"
    );
    if (!confirm) return;

    try {
      await deleteContent(id);
      setContents((prev) => prev.filter((c) => c.id !== id));
    } catch {
      alert("Failed to delete content");
    }
  };

  return (
    <div>
      <div className="row">
        <div >
          <div className="col-md-6">
        <h2>Content Management</h2>
      </div>

      <div className="col-md-6 mt-4 mb-4">
        <button
        type="button" className="btn btn-primary py-2 px-4 ms-3"
        onClick={() => navigate("/addContent")}
      >
        Add New Content
      </button>
      </div>
        </div>
      </div>

      <select value={type} onChange={(e) => setType(e.target.value)}>
        {Object.entries(CONTENT_TYPES).map(([key, label]) => (
          <option key={key} value={key}>
            {label}
          </option>
        ))}
      </select>

      {loading ? (
        <p>Loading...</p>
      ) : contents.length === 0 ? (
        <p>No content found</p>
      ) : (
        <table border="1" cellPadding="8" cellSpacing="0">
          <thead>
            <tr>
              <th>ID</th>
              <th>Type</th>
              <th>Title</th>
              <th>Public Id</th>
              <th>Created</th>
              <th>Actions</th>
            </tr>
          </thead>

          <tbody>
            {contents.map((item) => (
              <tr key={item.id}>
                <td>{item.id}</td>
                <td>{item.type}</td>
                <td>{item.title}</td>
                <td>{item.public_id}</td>
                <td>
                  {new Date(item.created_at).toLocaleDateString()}
                </td>
                <td>
                  <Link to={`/contents/edit/${item.id}`}>
                    Edit
                  </Link>
                  {" | "}
                  <button
                    onClick={() => handleDelete(item.id)}
                    style={{ color: "red" }}
                  >
                    Delete
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      )}
    </div>
  );
}
