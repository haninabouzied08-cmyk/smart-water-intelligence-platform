import { useState } from "react";
import api from "../api/axios";
import { useNavigate } from "react-router-dom";
import "../index.css"; 
import 'bootstrap/dist/css/bootstrap.min.css';
import 'bootstrap/dist/js/bootstrap.bundle.min';

export default function Login() {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const navigate = useNavigate();

  const handleSubmit = async (e) => {
    e.preventDefault();

    try {
      const res = await api.post("/auth/login", {
        email,
        password
      });

      if (res.data.role !== "admin") {
        alert("Access denied");
        return;
      }

      localStorage.setItem("admin_token", res.data.token);
      navigate("/contents");
    } catch (err) {
      alert("Invalid email or password");
    }
  };

  return (
    <div className="container">
      <div className="col-md-6 mt-5">
        <form onSubmit={handleSubmit}  class="form-group">
      <h2>Admin Login</h2>
      <div class="form-group">
        <label htmlFor="email1">Email address</label>
      <input
        id="email1"
        type="email"
        class="form-control"
        placeholder="Email"
        value={email}
        onChange={(e) => setEmail(e.target.value)}
        required
      />
      </div>

      <div class="form-group">
        <label for="password1">Password</label>
        <input
        id="password1"
        type="password"
        class="form-control"
        placeholder="Password"
        value={password}
        onChange={(e) => setPassword(e.target.value)}
        required
      />
      </div>

      <button type="submit" class="btn btn-primary mt-2">Login</button>
    </form>
      </div>
    </div>
  );
}
