import { useState } from "react";
import { uploadImage, uploadPdf } from "../api/upload.api";
import { createContent } from "../api/contents.api";

const CONTENT_TYPES = {
  blog: {
    label: "Blog",
    fields: ["link"]
  },
  workshop: {
    label: "Workshop",
    fields: ["pdf_file"]
  },
  event: {
    label: "Event & Webinar",
    fields: ["pdf_file"]
  },
  training: {
    label: "Training Course",
    fields: ["training_type", "language", "format", "training_objective"]
  },
  report: {
    label: "Report",
    fields: ["pdf_file"]
  },
  publication: {
    label: "Publication",
    fields: ["citation", "doi", "keyword"]
  },
  project: {
    label: "Project",
    fields: ["acronym", "end_date", "funding", "location", "partner", "objective", "goal", "activity"]
  }
};

export default function AddContent() {
  const [type, setType] = useState("blog");
  const [form, setForm] = useState({
    title: "",
    date: "",
    descr: "",
    link: "",
    acronym: "",
    end_date: "",
    funding: "",
    location: "",
    partner: "",
    objective: "",
    goal: "",
    activity: "",
    citation: "",
    doi: "",
    keyword: "",
    training_type: "",
    language: "",
    format: "",
    training_objective: ""
  });

  const [imageFile, setImageFile] = useState(null);
  const [pdfFile, setPdfFile] = useState(null);
  const [loading, setLoading] = useState(false);
  const [sessions, setSessions] = useState([]);

  const handleChange = (e) => {
    setForm({
      ...form,
      [e.target.name]: e.target.value
    });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);

    try {
      let pdfName = null;

      // Upload image if exists
      if (!imageFile) {
        alert("Image is required");
        setLoading(false);
        return;
      }

      const imageName = await uploadImage(imageFile);

      if (!imageName) {
        throw new Error("Image upload failed");
      }

      // Upload PDF only for reports
      if (type === "report") {
        if (!pdfFile) {
          alert("PDF file is required for reports");
          setLoading(false);
          return;
        }
        pdfName = await uploadPdf(pdfFile);
      }

      await createContent({
        type,
        base: {
          title: form.title,
          date: form.date || null,
          descr: form.descr,
          image: imageName
        },
        details: {
          link: form.link ?? null,
          acronym: form.acronym ?? null,
          end_date: form.end_date ?? null,
          funding: form.funding ?? null,
          location: form.location ?? null,
          partner: form.partner ?? null,
          objective: form.objective ?? null,
          goal: form.goal ?? null,
          activity: form.activity ?? null,
          citation: form.citation ?? null,
          doi: form.doi ?? null,
          keyword: form.keyword ?? null,

          training_type: form.training_type ?? null,
          language: form.language ?? null,
          format: form.format ?? null,
          training_objective: form.training_objective ?? null,

          report: pdfName ?? null
        },
        sessions: type === "training"
          ? sessions.map(s => ({
              title: s.title,
              date: s.date,
              link: s.link,
              trainer: s.trainer,
              descr: s.descr
            }))
          : []
      });


      alert("Content created successfully");

      // reset form
      setForm({
        title: "",
        date: "",
        descr: "",
        link: "",
        acronym: "",
        end_date: "",
        funding: "",
        location: "",
        partner: "",
        objective: "",
        goal: "",
        activity: "",
        citation: "",
        doi: "",
        keyword: "",
        training_type: "",
        language: "",
        format: "",
        training_objective: ""
      });
      setImageFile(null);
      setPdfFile(null);
      setType("blog");

    } catch (err) {
      alert(err.response?.data?.message || "Error creating content");
    } finally {
      setLoading(false);
    }
  };

  const fields = CONTENT_TYPES[type].fields;

  return (
    <form onSubmit={handleSubmit}>
      <h2>Add Content</h2>

      {/* Content type */}
      <select value={type} onChange={(e) => setType(e.target.value)}>
        {Object.entries(CONTENT_TYPES).map(([key, val]) => (
          <option key={key} value={key}>
            {val.label}
          </option>
        ))}
      </select>

      {/* Common fields */}
      <input
        name="title"
        placeholder="Title"
        value={form.title}
        onChange={handleChange}
        required
      />

      <input
        type="date"
        name="date"
        value={form.date}
        onChange={handleChange}
      />

      <textarea
        name="descr"
        placeholder="Description"
        value={form.descr}
        onChange={handleChange}
      />

      {/* Image upload */}
      <input
        type="file"
        accept="image/*"
        onChange={(e) => setImageFile(e.target.files[0])}
      />
      {fields.includes("link") && (
      <input
        type="link"
        name="link"
        placeholder="Link"
        value={form.link}
        onChange={handleChange}
      />
      )}


      {/* Training fields */}
      {fields.includes("training_type") && (
        <input
          name="training_type"
          placeholder="Training Type"
          value={form.training_type}
          onChange={handleChange}
        />
      )}

      {fields.includes("language") && (
        <input
          name="language"
          placeholder="Language"
          value={form.language}
          onChange={handleChange}
        />
      )}

      {fields.includes("training_objective") && (
        <textarea
          name="training_objective"
          placeholder="Objective"
          value={form.training_objective}
          onChange={handleChange}
        />
      )}

      {fields.includes("objective") && (
        <textarea
          name="objective"
          placeholder="Objective"
          value={form.objective}
          onChange={handleChange}
        />
      )}

      {fields.includes("format") && (
        <input
          name="format"
          placeholder="Format"
          value={form.format}
          onChange={handleChange}
        />
      )}

      {type === "training" && (
  <div>
    <h3>Training Sessions</h3>

    {sessions.map((s, index) => (
      <div key={index} style={{ border: "1px solid #ccc", padding: 10, marginBottom: 10 }}>
        <input
          placeholder="Session Title"
          value={s.title}
          onChange={(e) => {
            const copy = [...sessions];
            copy[index].title = e.target.value;
            setSessions(copy);
          }}
        />

        <input
          type="date"
          value={s.date}
          onChange={(e) => {
            const copy = [...sessions];
            copy[index].date = e.target.value;
            setSessions(copy);
          }}
        />

        <input
          placeholder="Session Link"
          value={s.link}
          onChange={(e) => {
            const copy = [...sessions];
            copy[index].link = e.target.value;
            setSessions(copy);
          }}
        />

        <input
          placeholder="Trainer"
          value={s.trainer}
          onChange={(e) => {
            const copy = [...sessions];
            copy[index].trainer = e.target.value;
            setSessions(copy);
          }}
        />

        <textarea
          placeholder="Description"
          value={s.descr}
          onChange={(e) => {
            const copy = [...sessions];
            copy[index].descr = e.target.value;
            setSessions(copy);
          }}
        />

        <button type="button" onClick={() =>
          setSessions(sessions.filter((_, i) => i !== index))
        }>
          Remove Session
        </button>
      </div>
    ))}

    <button
      type="button"
      onClick={() =>
        setSessions([...sessions, { title: "", date: "", link: "", trainer: "", descr: "" }])
      }
    >
      + Add Session
    </button>
  </div>
)}


      {/* Project fields */}

      {fields.includes("acronym") && (
        <input
          name="acronym"
          placeholder="Acronym"
          value={form.acronym}
          onChange={handleChange}
        />
      )}

      {fields.includes("end_date") && (
        <input
          type="date"
          name="end_date"
          placeholder="End Date"
          value={form.end_date}
          onChange={handleChange}
        />
      )}

      {fields.includes("funding") && (
        <input
          name="funding"
          placeholder="Funding"
          value={form.funding}
          onChange={handleChange}
        />
      )}

      {fields.includes("location") && (
        <input
          name="location"
          placeholder="location"
          value={form.location}
          onChange={handleChange}
        />
      )}

      {fields.includes("partner") && (
        <input
          name="partner"
          placeholder="Partner"
          value={form.partner}
          onChange={handleChange}
        />
      )}

      {fields.includes("goal") && (
        <textarea
          name="goal"
          placeholder="Goal"
          value={form.goal}
          onChange={handleChange}
        />
      )}

      {fields.includes("activity") && (
        <textarea
          name="activity"
          placeholder="Activity"
          value={form.activity}
          onChange={handleChange}
        />
      )}

      {fields.includes("citation") && (
        <textarea
          name="citation"
          placeholder="Citation"
          value={form.citation}
          onChange={handleChange}
        />
      )}

      {fields.includes("doi") && (
      <input
        type="link"
        name="doi"
        placeholder="Doi"
        value={form.doi}
        onChange={handleChange}
      />
      )}

      {fields.includes("keyword") && (
        <input
          name="keyword"
          placeholder="Keyword"
          value={form.keyword}
          onChange={handleChange}
        />
      )}

      {/* Report PDF */}
      {fields.includes("pdf_file") && (
        <input
          type="file"
          accept="application/pdf"
          onChange={(e) => setPdfFile(e.target.files[0])}
          required
        />
      )}

      <button disabled={loading}>
        {loading ? "Saving..." : "Create"}
      </button>
    </form>
  );
}
