import api from "./axios";

export const uploadImage = async (file) => {
  const formData = new FormData();
  formData.append("image", file);

  const res = await api.post(
    "/admin/upload/image",
    formData
  );

  return res.data.filename;
};

export const uploadPdf = async (file) => {
  const formData = new FormData();
  formData.append("report", file);

  const res = await api.post(
    "/admin/upload/report",
    formData
  );

  return res.data.filename;
};
