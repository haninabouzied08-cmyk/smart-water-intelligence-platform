import api from "./axios";

/**
 * CREATE content
 */
export const createContent = async (data) => {
  const res = await api.post("/admin/contents", {
    type: data.type,
    base: {
      title: data.base.title,
      date: data.base.date ?? null,
      descr: data.base.descr,
      image: data.base.image
    },
    details: data.details ?? {},
    sessions: data.sessions ?? []
  });

  return res.data;
};

/**
 * GET all contents
 */
export const getContents = async (type = "") => {
  const res = await api.get("/contents", {
    params: { type }
  });
  return res.data;
};

/**
 * GET content by ID
 */

export const getContentById = async (id) => {
  const res = await api.get(`/admin/contents/${id}`);
  return res.data;
};

/**
 * UPDATE content
 */

export const updateContent = async (id, data) => {
  const res = await api.put(`/admin/contents/${id}`, {
    type: data.type,
    base: {
      title: data.base.title,
      date: data.base.date ?? null,
      descr: data.base.descr,
      image: data.base.image ?? null
    },
    details: data.details ?? {},
    sessions: data.sessions ?? []
  });

  return res.data;
};

/**
 * DELETE content
 */
export const deleteContent = async (id) => {
  await api.delete(`/admin/contents/${id}`);
};
