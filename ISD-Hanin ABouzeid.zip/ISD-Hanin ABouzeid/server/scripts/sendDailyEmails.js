require("dotenv").config();
console.log("DB_USER:", process.env.DB_USER);
console.log("DB_PASSWORD:", process.env.DB_PASSWORD ? "SET" : "NOT SET");

const db = require("../config/db");
const { sendIrrigationEmail } = require("../utils/email");

async function run() {
  const [rows] = await db.query(`
    SELECT 
      u.email,
      s.crop_name,
      i.irrigation_mm,
      i.area_m2
    FROM irrigation_history i
    JOIN users u ON u.id = i.user_id
    JOIN swip_requests s ON s.id = i.swip_request_id
    WHERE DATE(i.irrigation_date) = CURDATE()
  `);

  for (const row of rows) {
    await sendIrrigationEmail(
      row.email,
      "🌱 Your Daily Irrigation Plan",
      `<p>Water today: ${(row.irrigation_mm * row.area_m2).toFixed(0)} liters</p>`
    );
  }

  process.exit();
}

run();
