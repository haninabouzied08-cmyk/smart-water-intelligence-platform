const { spawn } = require("child_process");
const path = require("path");

function runIrrigationAIInBackground(userId) {
  const scriptPath = path.join(
    __dirname,
    "../../lcwe/ai_service/fetch_weather_data.py"
  );

  const process = spawn("python", [
    scriptPath,
    "--user_id",
    userId
  ]);

  process.stdout.on("data", (data) => {
    console.log(`[AI ${userId}]`, data.toString());
  });

  process.stderr.on("data", (data) => {
    console.error(`[AI ERROR ${userId}]`, data.toString());
  });

  process.on("close", (code) => {
    console.log(`[AI ${userId}] finished with code ${code}`);
  });
}

module.exports = runIrrigationAIInBackground;
