const { exec } = require("child_process");
const path = require("path");
const pool = require("../config/db");

function runPythonScript(userId) {
  return new Promise((resolve, reject) => {
    const scriptPath = path.join(__dirname, "../../ai_service/fetch_weather_data.py");
    exec(`python "${scriptPath}" ${userId}`, (error, stdout, stderr) => {
      if (error) {
        console.error("Python error:", error);
        return reject(error);
      }
      if (stderr) {
        console.error("Python stderr:", stderr);
      }
      resolve(stdout);
    });
  });
}

async function fetchTodayIrrigation(userId) {
  // 1️⃣ Check if today's irrigation already exists
  const [existing] = await pool.execute(
    `SELECT * FROM irrigation_history
     WHERE user_id = ? AND DATE(irrigation_date) = CURDATE()
     ORDER BY irrigation_date DESC LIMIT 1`,
    [userId]
  );

  if (existing.length > 0) {
    return existing[0]; // ✅ return existing record
  }

  // 2️⃣ Otherwise run Python script to calculate & insert
  await runPythonScript(userId);

  // 3️⃣ Query again to get the newly inserted row
  const [rows] = await pool.execute(
    `SELECT * FROM irrigation_history
     WHERE user_id = ? AND DATE(irrigation_date) = CURDATE()
     ORDER BY irrigation_date DESC LIMIT 1`,
    [userId]
  );

  return rows[0];
}

module.exports = { fetchTodayIrrigation };
