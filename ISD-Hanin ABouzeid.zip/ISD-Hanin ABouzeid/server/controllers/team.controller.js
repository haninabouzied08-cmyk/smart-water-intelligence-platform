const pool = require("../config/db");

/**
 * PUBLIC – Get all team members
 */
exports.getTeam = async (req, res) => {
  const [rows] = await pool.execute(
    "SELECT * FROM team ORDER BY team, name"
  );
  res.json(rows);
};

/**
 * ADMIN – Create team member
 */
exports.createTeamMember = async (req, res) => {
  const { name, category, position, education, bio, cv, photo } = req.body;

  if (!name || !team) {
    return res.status(400).json({ message: "Name and team required" });
  }

  const [result] = await pool.execute(
    `INSERT INTO team (name, category, position, education, bio, cv, photo)
     VALUES (?, ?, ?, ?, ?, ?, ?)`,
    [name, category, position, education, bio, cv, photo]
  );

  res.json({ id: result.insertId });
};

/**
 * ADMIN – Update member
 */
exports.updateTeamMember = async (req, res) => {
  const { id } = req.params;

  await pool.execute(
    `UPDATE team SET ? WHERE id = ?`,
    [req.body, id]
  );

  res.json({ message: "Updated" });
};

/**
 * ADMIN – Delete member
 */
exports.deleteTeamMember = async (req, res) => {
  await pool.execute("DELETE FROM team WHERE id = ?", [req.params.id]);
  res.json({ message: "Deleted" });
};
