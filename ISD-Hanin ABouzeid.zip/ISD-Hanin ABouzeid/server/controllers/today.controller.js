const { fetchTodayIrrigation } = require("../services/irrigationService");

exports.getTodayIrrigation = async (req, res) => {
  try {
    const userId = req.user.id;
    const result = await fetchTodayIrrigation(userId);
    res.json(result);
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: "Failed to fetch today's irrigation" });
  }
};
