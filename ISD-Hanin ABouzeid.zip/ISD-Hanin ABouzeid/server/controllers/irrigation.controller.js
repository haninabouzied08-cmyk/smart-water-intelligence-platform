const pool = require("../config/db");

/**
 * Get irrigation history for the logged-in user
 */
exports.getIrrigationHistory = async (req, res) => {
  try {
    const userId = req.user.id; // comes from JWT middleware

    const [rows] = await pool.execute(
      `SELECT ih.id, ih.swip_request_id, ih.irrigation_date, ih.ET0, ih.Kc,
              ih.soil_moisture, ih.rainfall, ih.root_depth, ih.field_capacity,
              ih.area_m2, ih.irrigation_liters
       FROM irrigation_history ih
       WHERE ih.user_id = ?
       ORDER BY ih.irrigation_date DESC`,
      [userId]
    );

    res.json(rows);
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: "Failed to fetch irrigation history" });
  }
};
