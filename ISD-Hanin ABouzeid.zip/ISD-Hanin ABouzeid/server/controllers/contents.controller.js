const pool = require("../config/db");
const fs = require("fs");
const path = require("path");
const crypto = require("crypto");

const CONTENT_TYPES = {
  blog: "blog",
  event: "event",
  workshop: "workshop",
  report: "report",
  publication: "publication",
  training: "training",
  project: "project"
};


/**
 * CREATE CONTENT (ADMIN)
 */
exports.createContent = async (req, res) => {
  const connection = await pool.getConnection();
  const publicId = crypto.randomBytes(16).toString("hex");


  try {
    await connection.beginTransaction();

    const type = req.body.type;
    const base = req.body.base || {};
    const details = req.body.details || {};
    const sessions = Array.isArray(req.body.sessions) ? req.body.sessions : [];

    const safeBase = {
      title: base.title ?? null,
      date: base.date ?? null,
      descr: base.descr ?? null,
      image: base.image ?? null
    };

    if (!safeBase.image) {
      throw new Error("Image is required");
    }


    // 1️⃣ Insert core content
    const [result] = await connection.execute(
      `INSERT INTO contents (type, title, date, descr, image, public_id)
       VALUES (?, ?, ?, ?, ?, ?)`,
      [
        type,
        safeBase.title,
        safeBase.date,
        safeBase.descr,
        safeBase.image,
        publicId
      ]
    );

    const contentId = result.insertId;

    await insertDetails(connection, type, contentId, details);

    if (type === CONTENT_TYPES.training && Array.isArray(sessions)) {
      for (const session of sessions) {
        const s = (v) => v ?? null;

        await connection.execute(
          `INSERT INTO training_sessions_details
          (training_id, title, date, link, trainer, descr)
          VALUES (?, ?, ?, ?, ?, ?)`,
          [
            contentId,
            s(session.title),
            s(session.date),
            s(session.link),
            s(session.trainer),
            s(session.descr)
          ]
        );
      }
    }

    await connection.commit();
    res.status(201).json({ 
      id: contentId,
      public_id: publicId 
    });

  } catch (error) {
    await connection.rollback();

    // Cleanup uploaded files if transaction fails
    if (req.body.image) {
      const imgPath = path.join(__dirname, "..", "uploads", req.body.image);
      if (fs.existsSync(imgPath)) fs.unlinkSync(imgPath);
    }

    if (req.body.pdf_file) {
      const pdfPath = path.join(__dirname, "..", "uploads", req.body.pdf_file);
      if (fs.existsSync(pdfPath)) fs.unlinkSync(pdfPath);
    }

    res.status(400).json({ message: error.message });
  } finally {
    connection.release();
  }
};

/**
 * GET CONTENT LIST (PUBLIC)
 */
exports.getContents = async (req, res) => {
  try {
    const { type, limit } = req.query;

    let sql = `
      SELECT id, type, title, date, descr, image, public_id
      FROM contents
    `;
    const params = [];

    if (type) {
      sql += ` WHERE type = ?`;
      params.push(type);
    }

    sql += ` ORDER BY date DESC`;

    if (limit) {
      sql += ` LIMIT ?`;
      params.push(Number(limit));
    }

    const [rows] = await pool.execute(sql, params);
    res.json(rows);
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: "Failed to fetch contents" });
  }
};



/**
 * GET CONTENT DETAILS (PUBLIC)
 */
exports.getContentById = async (req, res) => {
  try {
    const { id } = req.params;

    const [baseRows] = await pool.execute(
      `SELECT * FROM contents WHERE id=?`,
      [id]
    );

    if (baseRows.length === 0) {
      return res.sendStatus(404);
    }

    const content = baseRows[0];

    // attach details
    content.details = await getDetailsByType(content.type, id);

    // attach sessions (training only)
    if (content.type === "training") {
      const [sessions] = await pool.execute(
        `SELECT * FROM training_sessions_details WHERE training_id=?`,
        [id]
      );
      content.sessions = sessions;
    }

    res.json(content);
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: "Failed to fetch content" });
  }
};

exports.getContentByPublicId = async (req, res) => {
  try {
    const { publicId } = req.params;

    const [rows] = await pool.execute(
      `SELECT * FROM contents WHERE public_id=?`,
      [publicId]
    );

    if (!rows.length) return res.sendStatus(404);

    const content = rows[0];

    content.details = await getDetailsByType(content.type, content.id);

    if (content.type === "training") {
      const [sessions] = await pool.execute(
        `SELECT * FROM training_sessions_details WHERE training_id=?`,
        [content.id]
      );
      content.sessions = sessions;
    }

    res.json(content);
  } catch (err) {
    res.status(500).json({ message: "Failed to fetch content" });
  }
};


async function getDetailsByType(type, id) {
  const tableMap = {
    blog: "blog_details",
    event: "simple_details",
    workshop: "simple_details",
    report: "simple_details",
    publication: "publication_details",
    training: "training_details",
    project: "project_details"
  };

  const table = tableMap[type];
  if (!table) return null;

  const [rows] = await pool.execute(
    `SELECT * FROM ${table} WHERE content_id=?`,
    [id]
  );

  return rows.length ? rows[0] : null;
}


/**
 * DELETE CONTENT (ADMIN)
 */

exports.deleteContent = async (req, res) => {
  try {
    const { id } = req.params;

    // 1️⃣ Get image filename
    const [contentRows] = await pool.execute(
      `SELECT image FROM contents WHERE id=?`,
      [id]
    );

    if (contentRows.length === 0) {
      return res.sendStatus(404);
    }

    const image = contentRows[0].image;

    // 2️⃣ Get report filename (if exists)
    const [reportRows] = await pool.execute(
      `SELECT report FROM simple_details WHERE content_id=?`,
      [id]
    );

    const report =
      reportRows.length > 0 ? reportRows[0].report : null;

    // 3️⃣ Delete image file
    if (image) {
      const imgPath = path.join(
        __dirname,
        "..",
        "uploads",
        "images",
        image
      );
      if (fs.existsSync(imgPath)) {
        fs.unlinkSync(imgPath);
      }
    }

    // 4️⃣ Delete report file
    if (report) {
      const reportPath = path.join(
        __dirname,
        "..",
        "uploads",
        "reports",
        report
      );
      if (fs.existsSync(reportPath)) {
        fs.unlinkSync(reportPath);
      }
    }

    // 5️⃣ Delete DB row (cascade handles the rest)
    await pool.execute(`DELETE FROM contents WHERE id=?`, [id]);

    res.sendStatus(204);
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: "Failed to delete content" });
  }
};


exports.updateContent = async (req, res) => {
  const connection = await pool.getConnection();

  try {
    await connection.beginTransaction();

    const { id } = req.params;
    const { type, base, details, sessions } = req.body;

    // 0️⃣ Get old image
    const [oldRows] = await connection.execute(
      `SELECT image FROM contents WHERE id=?`,
      [id]
    );

    if (oldRows.length === 0) {
      throw new Error("Content not found");
    }

    const oldImage = oldRows[0].image;

    // 1️⃣ Update main content
    await connection.execute(
      `UPDATE contents 
       SET title=?, date=?, descr=?, image=? 
       WHERE id=? AND type=?`,
      [
        base.title,
        base.date,
        base.descr,
        base.image || oldImage,
        id,
        type
      ]
    );

    // 2️⃣ Replace details
    await deleteDetails(connection, type, id);
    await insertDetails(connection, type, id, details);

    // 3️⃣ Delete old image if replaced
    if (base.image && base.image !== oldImage && oldImage) {
      const oldPath = path.join(__dirname, "..", "uploads", "images", oldImage);
      if (fs.existsSync(oldPath)) fs.unlinkSync(oldPath);
    }

    // 4️⃣ Training sessions
    if (type === "training") {
      await connection.execute(
        `DELETE FROM training_sessions_details WHERE training_id=?`,
        [id]
      );

      if (Array.isArray(sessions)) {
        for (const s of sessions) {
          await connection.execute(
            `INSERT INTO training_sessions_details
             (training_id, title, date, link, trainer, descr)
             VALUES (?, ?, ?, ?, ?, ?)`,
            [
              id,
              s.title ?? null,
              s.date ?? null,
              s.link ?? null,
              s.trainer ?? null,
              s.descr ?? null
            ]
          );
        }
      }
    }

    await connection.commit();
    res.sendStatus(204);

  } catch (err) {
    await connection.rollback();
    console.error(err);
    res.status(500).json({ message: err.message });
  } finally {
    connection.release();
  }
};

/**
 * SEARCH CONTENTS (PUBLIC)
 */
exports.searchContents = async (req, res) => {
  try {
    const { keyword, type, limit } = req.query;

    if (!keyword) {
      return res.status(400).json({ message: "Keyword is required" });
    }

    let sql = `
      SELECT id, type, title, date, descr, image, public_id
      FROM contents
      WHERE title LIKE ? OR descr LIKE ?
    `;
    const params = [`%${keyword}%`, `%${keyword}%`];

    if (type) {
      sql += ` AND type = ?`;
      params.push(type);
    }

    sql += ` ORDER BY date DESC`;

    if (limit) {
      sql += ` LIMIT ?`;
      params.push(Number(limit));
    }

    const [rows] = await pool.execute(sql, params);
    res.json(rows);
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: "Failed to search contents" });
  }
};


async function insertDetails(conn, type, contentId, d = {}) {
  const safe = (v) => v ?? null;

  switch (type) {
    case "blog":
      await conn.execute(
        `INSERT INTO blog_details (content_id, link)
         VALUES (?, ?)`,
        [contentId, safe(d.link)]
      );
      break;

    case "event":
    case "workshop":
    case "report":
      await conn.execute(
        `INSERT INTO simple_details (content_id, report)
         VALUES (?, ?)`,
        [contentId, safe(d.report)]
      );
      break;

    case "publication":
      await conn.execute(
        `INSERT INTO publication_details
         (content_id, citation, doi, keyword)
         VALUES (?, ?, ?, ?)`,
        [
          contentId,
          safe(d.citation),
          safe(d.doi),
          safe(d.keyword)
        ]
      );
      break;

    case "training":
      await conn.execute(
        `INSERT INTO training_details
         (content_id, type, language, objective, format)
         VALUES (?, ?, ?, ?, ?)`,
        [
          contentId,
          safe(d.training_type),   // ⚠️ FIXED
          safe(d.language),
          safe(d.training_objective),
          safe(d.format)
        ]
      );
      break;

    case "project":
      await conn.execute(
        `INSERT INTO project_details
         (content_id, acronym, end_date, funding, location,
          partner, objective, goal, activity)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`,
        [
          contentId,
          safe(d.acronym),
          safe(d.end_date),
          safe(d.funding),
          safe(d.location),
          safe(d.partner),
          safe(d.objective),
          safe(d.goal),
          safe(d.activity)
        ]
      );
      break;

    default:
      throw new Error("Unsupported content type");
  }
}


async function deleteDetails(conn, type, contentId) {
  const tableMap = {
    blog: "blog_details",
    event: "simple_details",
    workshop: "simple_details",
    report: "simple_details",
    publication: "publication_details",
    training: "training_details",
    project: "project_details"
  };

  const table = tableMap[type];
  if (!table) throw new Error("Invalid content type");

  await conn.execute(
    `DELETE FROM ${table} WHERE content_id=?`,
    [contentId]
  );
}
