require("dotenv").config();
const express = require("express");
const cors = require("cors");
const path = require("path");

const authRoutes = require("./routes/auth.routes");
const adminRoutes = require("./routes/admin.routes");
const publicRoutes = require("./routes/public.routes");

const cropRoutes = require("./routes/crops");
const swipRoutes = require("./routes/swipRoutes");
const irrigationRoutes = require("./routes/irrigation.routes");
const todayRoutes = require("./routes/today.routes");

const contactRoutes = require("./routes/contact.routes");
const app = express();

// Middleware
app.use(cors());
app.use(express.json());

// Static uploads
app.use("/uploads", express.static(path.join(__dirname, "uploads")));

// ✅ PUBLIC ROUTES
app.use("/api", authRoutes);
app.use("/api", publicRoutes);
app.use("/api/crops", cropRoutes);

// ✅ PROTECTED ROUTES
app.use("/api/swip", swipRoutes);
app.use("/api", irrigationRoutes);
app.use("/api", todayRoutes);
app.use("/api", contactRoutes);

// 🔐 ADMIN ONLY
app.use("/api/admin", adminRoutes);

app.get("/test", (req, res) => {
  res.send("API is working");
});

app.use((err, req, res, next) => {
  console.error(err);
  res.status(400).json({ message: err.message });
});

const PORT = process.env.PORT || 5000;
app.listen(PORT, () => {
  console.log(`API running on port ${PORT}`);
});
