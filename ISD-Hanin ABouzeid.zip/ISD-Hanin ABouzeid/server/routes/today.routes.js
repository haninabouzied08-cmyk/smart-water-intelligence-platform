const express = require("express");
const router = express.Router();
const authenticate = require("../middleware/authenticate");
const todayController = require("../controllers/today.controller");

router.get("/irrigation/today", authenticate, todayController.getTodayIrrigation);

module.exports = router;
