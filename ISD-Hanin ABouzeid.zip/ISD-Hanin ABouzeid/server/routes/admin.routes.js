const express = require("express");
const router = express.Router();

const authenticate = require("../middleware/authenticate");
const requireAdmin = require("../middleware/requireAdmin");
const uploadImage = require("../middleware/uploadImage");
const uploadPdf = require("../middleware/uploadPdf");

const {
  createContent,
  updateContent,
  deleteContent,
  getContentById,
  getContents,
  getContentByPublicId
} = require("../controllers/contents.controller");

/* =====================================================
   🔓 PUBLIC ROUTES (MAIN WEBSITE)
   ===================================================== */

// List contents (optionally filtered by type)
router.get("/contents", getContents);

// Get single content by public ID
router.get("/contents/public/:publicId", getContentByPublicId);

/* =====================================================
   🔒 ADMIN ROUTES (PROTECTED)
   ===================================================== */

router.use(authenticate, requireAdmin);

// ---------- UPLOADS ----------

router.post(
  "/upload/image",
  uploadImage.single("image"),
  (req, res) => {
    res.json({ filename: req.file.filename });
  }
);

router.post(
  "/upload/report",
  uploadPdf.single("report"),
  (req, res) => {
    res.json({ filename: req.file.filename });
  }
);

// ---------- CONTENT MANAGEMENT ----------

router.get("/contents/:id", getContentById); 
router.post("/contents", createContent); 
router.put("/contents/:id", updateContent); 
router.delete("/contents/:id", deleteContent);

module.exports = router;
