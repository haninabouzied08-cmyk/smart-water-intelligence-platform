const express = require("express");
const router = express.Router();
const irrigationController = require("../controllers/irrigation.controller");
const authenticate = require("../middleware/authenticate");

// Protected route: only logged-in users can access their irrigation history
router.get("/irrigation/history", authenticate, irrigationController.getIrrigationHistory);

module.exports = router;
