const express = require("express");
const db = require("../config/db");
const authMiddleware = require("../middleware/authenticate");

const router = express.Router();

router.post("/swip-request", authMiddleware, async (req, res) => {
  const {
    crop_name,
    crop_type,
    crop_phase,
    soil_type,
    area_m2,
  } = req.body;

  const user_id = req.user.id;

  if (!area_m2 || area_m2 <= 0) {
    return res.status(400).json({ error: "Invalid area" });
  }

  try {
    // 1️⃣ Save SWIP request
    await db.execute(
      `
      INSERT INTO swip_requests
      (user_id, crop_name, crop_type, crop_phase, soil_type, area_m2)
      VALUES (?, ?, ?, ?, ?, ?)
      `,
      [user_id, crop_name, crop_type, crop_phase, soil_type, area_m2]
    );

    // 3️⃣ Respond immediately
    res.json({
      message: "SWIP submitted. Irrigation will be generated shortly."
    });

  } catch (err) {
    console.error("SWIP error:", err);
    res.status(500).json({ error: "Failed to submit SWIP request" });
  }
});

module.exports = router;
