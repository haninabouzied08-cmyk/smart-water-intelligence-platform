const express = require("express");
const router = express.Router();
const contentsController = require("../controllers/contents.controller");

// list
router.get("/contents", contentsController.getContents);

// 🔑 DETAILS BY PUBLIC ID
router.get(
  "/contents/public/:publicId",
  contentsController.getContentByPublicId
);

router.get("/contents/search", contentsController.searchContents);


module.exports = router;
