const express = require("express");
const fs = require("fs");
const csv = require("csv-parser");
const path = require("path");

const router = express.Router();

// Path to CSV file
const DATA_PATH = path.join(__dirname, "../data/crop_environment_dataset.csv");

/**
 * 1️⃣ Get unique crop types
 * URL: GET /api/crops/crop-types
 */
router.get("/crop-types", (req, res) => {
  const types = new Set();

  fs.createReadStream(DATA_PATH)
    .pipe(csv())
    .on("data", (row) => {
      // 🔧 SAFELY get crop_type even if CSV has BOM or spacing
      const cropTypeKey = Object.keys(row).find(
        (key) => key.trim() === "crop_type"
      );

      if (cropTypeKey && row[cropTypeKey]) {
        types.add(row[cropTypeKey].trim());
      }
    })
    .on("end", () => {
      res.json(Array.from(types));
    })
    .on("error", (err) => {
      console.error("CSV read error:", err);
      res.status(500).json({ message: "Failed to read crop data" });
    });
});

/**
 * 2️⃣ Get crop names by crop type
 * URL: GET /api/crops/by-type/:type
 */
router.get("/by-type/:type", (req, res) => {
  const selectedType = req.params.type.trim();
  const crops = [];

  fs.createReadStream(DATA_PATH)
    .pipe(csv())
    .on("data", (row) => {
      const cropTypeKey = Object.keys(row).find(
        (key) => key.trim() === "crop_type"
      );
      const cropNameKey = Object.keys(row).find(
        (key) => key.trim() === "crop_name"
      );

      if (
        cropTypeKey &&
        cropNameKey &&
        row[cropTypeKey] &&
        row[cropNameKey] &&
        row[cropTypeKey].trim() === selectedType
      ) {
        crops.push(row[cropNameKey].trim());
      }
    })
    .on("end", () => {
      res.json(crops);
    })
    .on("error", (err) => {
      console.error("CSV read error:", err);
      res.status(500).json({ message: "Failed to read crop data" });
    });
});

module.exports = router;
